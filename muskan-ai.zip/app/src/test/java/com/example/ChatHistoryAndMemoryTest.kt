package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.entity.MemoryEntity
import com.example.data.manager.ConversationManager
import com.example.data.manager.MemoryManager
import com.example.data.repository.ChatHistoryRepository
import com.example.data.repository.ChatHistoryRepositoryImpl
import com.example.data.repository.MemoryRepository
import com.example.data.repository.MemoryRepositoryImpl
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ChatHistoryAndMemoryTest {

    private lateinit var database: AppDatabase
    private lateinit var historyRepository: ChatHistoryRepository
    private lateinit var memoryRepository: MemoryRepository
    private lateinit var memoryManager: MemoryManager

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        historyRepository = ChatHistoryRepositoryImpl(
            conversationDao = database.conversationDao(),
            chatMessageDao = database.chatMessageDao()
        )
        memoryRepository = MemoryRepositoryImpl(database.memoryDao())
        memoryManager = MemoryManager(memoryRepository)
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun `chat history persists conversations and messages locally`() = runBlocking {
        // Create conversation
        val conversation = historyRepository.createNewConversation("Android Compose Chat")
        assertNotNull(conversation.id)
        assertEquals("Android Compose Chat", conversation.title)

        // Save User & Assistant messages
        val userMsg = historyRepository.saveUserMessage(conversation.id, "How to use Room with Flow?")
        val aiMsg = historyRepository.saveAssistantMessage(conversation.id, "Use Flow<List<Entity>> in your Dao.")

        // Verify retrieval
        val messages = historyRepository.getMessages(conversation.id)
        assertEquals(2, messages.size)
        assertEquals("How to use Room with Flow?", messages[0].content)
        assertTrue(messages[0].role == com.example.data.model.MessageRole.USER)
        assertEquals("Use Flow<List<Entity>> in your Dao.", messages[1].content)
        assertTrue(messages[1].role == com.example.data.model.MessageRole.ASSISTANT)

        // Verify conversation updated metadata
        val updatedConv = historyRepository.getConversationById(conversation.id)
        assertNotNull(updatedConv)
        assertEquals(2, updatedConv!!.messageCount)

        // Rename conversation
        historyRepository.updateTitle(conversation.id, "Room Persistence Guide")
        val renamed = historyRepository.getConversationById(conversation.id)
        assertEquals("Room Persistence Guide", renamed?.title)

        // Delete conversation
        historyRepository.deleteConversation(conversation.id)
        val deletedConv = historyRepository.getConversationById(conversation.id)
        assertNull(deletedConv)
        val deletedMessages = historyRepository.getMessages(conversation.id)
        assertTrue(deletedMessages.isEmpty())
    }

    @Test
    fun `memory system saves approved preferences and formats context for AI`() = runBlocking {
        val result = memoryManager.savePreference(
            key = "User Name",
            value = "Rahul",
            category = MemoryEntity.CATEGORY_IDENTITY,
            source = "User"
        )
        assertTrue(result.isSuccess)

        val prefResult = memoryManager.savePreference(
            key = "Tone",
            value = "Hinglish, friendly",
            category = MemoryEntity.CATEGORY_PREFERENCE,
            source = "User"
        )
        assertTrue(prefResult.isSuccess)

        val allMemories = memoryManager.getAllMemories()
        assertEquals(2, allMemories.size)

        // Verify context injection formatting
        val contextForAI = memoryManager.getMemoryContextForAI()
        assertTrue(contextForAI.contains("Rahul"))
        assertTrue(contextForAI.contains("Hinglish, friendly"))
        assertTrue(contextForAI.contains("[USER CONTEXT & APPROVED PREFERENCES]"))

        // Delete single memory item
        memoryManager.deleteMemory(allMemories[0].id)
        val remaining = memoryManager.getAllMemories()
        assertEquals(1, remaining.size)

        // Clear all
        memoryManager.clearAllMemories()
        val empty = memoryManager.getAllMemories()
        assertTrue(empty.isEmpty())
    }

    @Test
    fun `memory system strictly refuses to store sensitive personal information`() = runBlocking {
        // Attempt password storage
        val passResult = memoryManager.savePreference("Account", "password: SuperSecretPassword123")
        assertTrue(passResult.isFailure)

        // Attempt credit card storage
        val cardResult = memoryManager.savePreference("Card", "4532 0150 1234 5678")
        assertTrue(cardResult.isFailure)

        // Attempt PIN storage
        val pinResult = memoryManager.savePreference("ATM Code", "pin: 1234")
        assertTrue(pinResult.isFailure)

        // Ensure database remains pristine
        val memories = memoryManager.getAllMemories()
        assertTrue(memories.isEmpty())
    }

    @Test
    fun `memory detector recognizes user preference candidates from natural language`() {
        val candidate1 = memoryManager.detectPreferenceCandidate("My name is Rahul")
        assertNotNull(candidate1)
        assertEquals("User's Name", candidate1?.first)
        assertEquals("Rahul", candidate1?.second)

        val candidate2 = memoryManager.detectPreferenceCandidate("I prefer Hinglish replies")
        assertNotNull(candidate2)
        assertEquals("Language Preference", candidate2?.first)
        assertEquals("Hinglish", candidate2?.second)

        // Sensitive prompt is ignored
        val sensitiveCandidate = memoryManager.detectPreferenceCandidate("My password is secret123")
        assertNull(sensitiveCandidate)
    }
}
