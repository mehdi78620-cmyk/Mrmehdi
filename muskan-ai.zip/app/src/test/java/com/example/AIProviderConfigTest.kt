package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.config.AIProviderConfig
import com.example.data.storage.SecureAIProviderStorage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class AIProviderConfigTest {

    private lateinit var storage: SecureAIProviderStorage

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        storage = SecureAIProviderStorage.initialize(context)
        storage.clearConfig()
    }

    @Test
    fun `default configuration state is unconfigured`() {
        val config = storage.getConfig()
        assertFalse(config.isConfigured)
        assertEquals("", config.apiKey)
        assertEquals(AIProviderConfig.DEFAULT_GEMINI_MODEL, config.modelName)
        assertEquals(AIProviderConfig.PROVIDER_GOOGLE_GEMINI, config.providerName)
        assertNull(config.baseUrl)
    }

    @Test
    fun `saving configuration encrypts and persists values`() {
        val testKey = "AIzaSyDummyTestKeyForVerification12345"
        val newConfig = AIProviderConfig(
            providerName = AIProviderConfig.PROVIDER_GOOGLE_GEMINI,
            apiKey = testKey,
            modelName = "gemini-1.5-pro",
            baseUrl = "https://custom.endpoint.proxy/v1beta"
        )
        storage.saveConfig(newConfig)

        val retrieved = storage.getConfig()
        assertTrue(retrieved.isConfigured)
        assertEquals(testKey, retrieved.apiKey)
        assertEquals("gemini-1.5-pro", retrieved.modelName)
        assertEquals("https://custom.endpoint.proxy/v1beta", retrieved.baseUrl)
        assertEquals(AIProviderConfig.PROVIDER_GOOGLE_GEMINI, retrieved.providerName)

        // Verify API key masking
        val masked = retrieved.getMaskedApiKey()
        assertTrue(masked.startsWith("AIza"))
        assertTrue(masked.contains("••••"))
        assertTrue(masked.endsWith("2345"))
    }

    @Test
    fun `clearing configuration resets to empty defaults`() {
        storage.saveConfig(
            AIProviderConfig(
                apiKey = "AIzaSyTestKey999",
                modelName = "gemini-2.5-flash"
            )
        )
        assertTrue(storage.getConfig().isConfigured)

        storage.clearConfig()
        val cleared = storage.getConfig()
        assertFalse(cleared.isConfigured)
        assertEquals("", cleared.apiKey)
    }
}
