package com.example

import com.example.tools.ToolCallingEngine
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.json.JSONObject

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ToolCallingEngineTest {

    private val toolEngine = ToolCallingEngine()

    @Test
    fun `all 6 required tools are registered`() {
        val tools = toolEngine.getAllTools()
        assertEquals(6, tools.size)

        assertNotNull(toolEngine.getTool("get_weather"))
        assertNotNull(toolEngine.getTool("calculator"))
        assertNotNull(toolEngine.getTool("get_time_date"))
        assertNotNull(toolEngine.getTool("web_search"))
        assertNotNull(toolEngine.getTool("open_url"))
        assertNotNull(toolEngine.getTool("basic_info_retrieval"))
    }

    @Test
    fun `calculator tool evaluates expressions correctly`() = runBlocking {
        val calcTool = toolEngine.getTool("calculator")
        assertNotNull(calcTool)

        val args = JSONObject().put("expression", "10 + 5 * 2")
        val result = calcTool!!.execute(args)
        assertTrue(result.success)
        assertTrue(result.output.contains("20.0") || result.output.contains("20"))
    }

    @Test
    fun `time date tool returns current timestamp info`() = runBlocking {
        val timeTool = toolEngine.getTool("get_time_date")
        assertNotNull(timeTool)

        val result = timeTool!!.execute(JSONObject())
        assertTrue(result.success)
        assertTrue(result.output.contains("Current Date and Time"))
    }

    @Test
    fun `gemini tool declarations schema is well formed`() {
        val declarations = toolEngine.getGeminiToolDeclarations()
        assertTrue(declarations.length() > 0)
        val firstWrapper = declarations.getJSONObject(0)
        assertTrue(firstWrapper.has("functionDeclarations"))
    }
}
