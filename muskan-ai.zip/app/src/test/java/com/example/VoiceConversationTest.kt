package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.manager.ConversationManager
import com.example.data.manager.MemoryManager
import com.example.data.repository.ChatHistoryRepositoryImpl
import com.example.data.repository.MemoryRepositoryImpl
import com.example.ui.screens.chat.ChatViewModel
import com.example.voice.SpeechRecognitionHelper
import com.example.voice.TextToSpeechHelper
import com.example.voice.VoiceLanguage
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class VoiceConversationTest {

    private lateinit var context: Context
    private lateinit var database: AppDatabase
    private lateinit var conversationManager: ConversationManager
    private lateinit var speechHelper: SpeechRecognitionHelper
    private lateinit var ttsHelper: TextToSpeechHelper
    private lateinit var viewModel: ChatViewModel

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext<Context>()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()

        val historyRepo = ChatHistoryRepositoryImpl(
            conversationDao = database.conversationDao(),
            chatMessageDao = database.chatMessageDao()
        )
        val memoryRepo = MemoryRepositoryImpl(database.memoryDao())
        val memoryManager = MemoryManager(memoryRepo)

        conversationManager = ConversationManager(
            historyRepository = historyRepo,
            memoryManager = memoryManager
        )

        speechHelper = SpeechRecognitionHelper(context)
        ttsHelper = TextToSpeechHelper(context)
        viewModel = ChatViewModel(
            conversationManager = conversationManager,
            speechRecognitionHelper = speechHelper,
            textToSpeechHelper = ttsHelper
        )
    }

    @After
    fun tearDown() {
        speechHelper.destroy()
        ttsHelper.shutdown()
        database.close()
    }

    @Test
    fun `voice language choices support Hindi, Hinglish and English`() {
        assertEquals("hi-IN", VoiceLanguage.HINDI.tag)
        assertEquals("हिंदी", VoiceLanguage.HINDI.displayName)

        assertEquals("en-IN", VoiceLanguage.HINGLISH.tag)
        assertEquals("Hinglish", VoiceLanguage.HINGLISH.displayName)

        assertEquals("en-US", VoiceLanguage.ENGLISH.tag)
        assertEquals("English", VoiceLanguage.ENGLISH.displayName)

        assertEquals(VoiceLanguage.HINDI, VoiceLanguage.fromTag("hi-IN"))
        assertEquals(VoiceLanguage.HINGLISH, VoiceLanguage.fromTag("en-IN"))
        assertEquals(VoiceLanguage.ENGLISH, VoiceLanguage.fromTag("en-US"))
    }

    @Test
    fun `tts cleaner strips markdown formatting for natural voice output`() {
        val markdownText = "**Namaste!** Main `Muskan` hoon. Check out [link](https://example.com) for details! ### Section"
        val cleaned = ttsHelper.cleanTextForSpeech(markdownText)

        assertFalse(cleaned.contains("**"))
        assertFalse(cleaned.contains("`"))
        assertFalse(cleaned.contains("###"))
        assertFalse(cleaned.contains("https://"))
        assertTrue(cleaned.contains("Namaste!"))
        assertTrue(cleaned.contains("Main Muskan hoon"))
    }

    @Test
    fun `viewModel updates language and observes speech state`() {
        viewModel.setVoiceLanguage(VoiceLanguage.HINGLISH)
        assertEquals("en-IN", viewModel.uiState.value.voiceLanguage)

        viewModel.setVoiceLanguage(VoiceLanguage.HINDI)
        assertEquals("hi-IN", viewModel.uiState.value.voiceLanguage)
    }

    @Test
    fun `viewModel handles permission denial correctly`() {
        viewModel.onPermissionDenied()
        val state = viewModel.uiState.value
        assertTrue(state.permissionDenied)
        assertFalse(state.isListening)
        assertNotNull(state.voiceError)

        viewModel.clearVoiceError()
        assertFalse(viewModel.uiState.value.permissionDenied)
        assertEquals(null, viewModel.uiState.value.voiceError)
    }

    @Test
    fun `transcribed voice text populates chat input and can be sent`() = runBlocking {
        // User speaks and transcribed text arrives
        viewModel.onInputTextChanged("Aapka naam kya hai?")
        assertEquals("Aapka naam kya hai?", viewModel.uiState.value.inputText)

        // User sends the transcribed message
        viewModel.sendMessage()

        val messages = viewModel.uiState.value.messages
        assertTrue("Expected messages list to contain user message", messages.isNotEmpty())
        val userMessage = messages.firstOrNull { it.isUser }
        assertNotNull(userMessage)
        assertEquals("Aapka naam kya hai?", userMessage?.text)
        assertEquals("", viewModel.uiState.value.inputText)
    }

    @Test
    fun `auto TTS can be toggled on and off`() {
        assertTrue(viewModel.uiState.value.autoTtsEnabled)
        viewModel.toggleAutoTts()
        assertFalse(viewModel.uiState.value.autoTtsEnabled)
        viewModel.toggleAutoTts()
        assertTrue(viewModel.uiState.value.autoTtsEnabled)
    }
}
