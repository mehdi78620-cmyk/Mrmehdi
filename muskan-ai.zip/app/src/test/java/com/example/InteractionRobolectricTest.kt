package com.example

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performTextInput
import com.example.navigation.AppNavigation
import com.example.ui.theme.MuskanAITheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class InteractionRobolectricTest {

    @get:Rule
    val composeTestRule = createComposeRule()

    @Test
    fun testAllMajorInteractionsAndRoutes() {
        composeTestRule.setContent {
            MuskanAITheme {
                AppNavigation()
            }
        }

        // 1. Home Screen is displayed
        composeTestRule.onNodeWithTag("muskan_home_screen").assertIsDisplayed()

        // 2. Settings button opens Settings screen & back navigates back
        composeTestRule.onNodeWithTag("settings_button").assertIsDisplayed().performClick()
        composeTestRule.onNodeWithTag("settings_screen").assertIsDisplayed()
        composeTestRule.onNodeWithTag("settings_back_button").performClick()
        composeTestRule.onNodeWithTag("muskan_home_screen").assertIsDisplayed()

        // 3. Hamburger Menu button opens Settings/More screen & back navigates back
        composeTestRule.onNodeWithTag("menu_button").assertIsDisplayed().performClick()
        composeTestRule.onNodeWithTag("settings_screen").assertIsDisplayed()
        composeTestRule.onNodeWithTag("settings_back_button").performClick()
        composeTestRule.onNodeWithTag("muskan_home_screen").assertIsDisplayed()

        // 4. Feature Card: Web Search -> navigates to Chat & back
        composeTestRule.onNodeWithTag("feature_card_web_search").performScrollTo().performClick()
        composeTestRule.onNodeWithTag("muskan_chat_screen").assertIsDisplayed()
        composeTestRule.onNodeWithTag("chat_back_button").performClick()
        composeTestRule.onNodeWithTag("muskan_home_screen").assertIsDisplayed()

        // 5. Feature Card: Coding -> navigates to Chat & back
        composeTestRule.onNodeWithTag("feature_card_coding").performScrollTo().performClick()
        composeTestRule.onNodeWithTag("muskan_chat_screen").assertIsDisplayed()
        composeTestRule.onNodeWithTag("chat_back_button").performClick()
        composeTestRule.onNodeWithTag("muskan_home_screen").assertIsDisplayed()

        // 6. Feature Card: Chat -> Chat Screen
        composeTestRule.onNodeWithTag("feature_card_chat").performScrollTo().performClick()
        composeTestRule.onNodeWithTag("muskan_chat_screen").assertIsDisplayed()

        // 7. Chat input focus, typing & send
        composeTestRule.onNodeWithTag("chat_input_field").performTextInput("Hello Muskan AI")
        composeTestRule.onNodeWithTag("chat_send_button").assertIsDisplayed().performClick()

        // 8. Chat microphone button click
        composeTestRule.onNodeWithTag("chat_microphone_button").assertIsDisplayed().performClick()

        // 9. Back to Home
        composeTestRule.onNodeWithTag("chat_back_button").performClick()
        composeTestRule.onNodeWithTag("muskan_home_screen").assertIsDisplayed()

        // 10. History navigation tab & back
        composeTestRule.onNodeWithTag("nav_history_button").assertIsDisplayed().performClick()
        composeTestRule.onNodeWithTag("history_screen").assertIsDisplayed()
        composeTestRule.onNodeWithTag("history_back_button").performClick()
        composeTestRule.onNodeWithTag("muskan_home_screen").assertIsDisplayed()

        // 11. Large Microphone button on Home screen
        composeTestRule.onNodeWithTag("large_glowing_microphone_button").assertIsDisplayed().performClick()
        composeTestRule.onNodeWithTag("muskan_chat_screen").assertIsDisplayed()
    }
}
