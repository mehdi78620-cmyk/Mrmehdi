package com.example.ui.screens.memory

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.MemoryEntity
import com.example.data.manager.MemoryManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class MemoryViewModel(
    private val memoryManager: MemoryManager = MemoryManager.getInstance()
) : ViewModel() {

    private val _uiState = MutableStateFlow(MemoryUiState(isLoading = true))
    val uiState: StateFlow<MemoryUiState> = _uiState.asStateFlow()

    init {
        observeMemories()
    }

    private fun observeMemories() {
        viewModelScope.launch {
            memoryManager.getAllMemoriesFlow().collect { list ->
                _uiState.update { current ->
                    current.copy(
                        memories = list,
                        filteredMemories = filterByCategory(list, current.selectedCategory),
                        isLoading = false
                    )
                }
            }
        }
    }

    fun onCategorySelected(category: String?) {
        _uiState.update { current ->
            current.copy(
                selectedCategory = category,
                filteredMemories = filterByCategory(current.memories, category)
            )
        }
    }

    private fun filterByCategory(list: List<MemoryEntity>, category: String?): List<MemoryEntity> {
        if (category == null) return list
        return list.filter { it.category.equals(category, ignoreCase = true) }
    }

    fun onOpenAddDialog() {
        _uiState.update {
            it.copy(
                showAddDialog = true,
                newKeyInput = "",
                newValueInput = "",
                newCategoryInput = MemoryEntity.CATEGORY_PREFERENCE,
                errorMessage = null
            )
        }
    }

    fun onDismissAddDialog() {
        _uiState.update {
            it.copy(
                showAddDialog = false,
                newKeyInput = "",
                newValueInput = "",
                errorMessage = null
            )
        }
    }

    fun onKeyInputChange(key: String) {
        _uiState.update { it.copy(newKeyInput = key, errorMessage = null) }
    }

    fun onValueInputChange(value: String) {
        _uiState.update { it.copy(newValueInput = value, errorMessage = null) }
    }

    fun onCategoryInputChange(category: String) {
        _uiState.update { it.copy(newCategoryInput = category) }
    }

    fun onSaveMemory() {
        val key = _uiState.value.newKeyInput.trim()
        val value = _uiState.value.newValueInput.trim()
        val category = _uiState.value.newCategoryInput

        if (key.isEmpty() || value.isEmpty()) {
            _uiState.update { it.copy(errorMessage = "Please enter both label and value.") }
            return
        }

        viewModelScope.launch {
            val result = memoryManager.savePreference(
                key = key,
                value = value,
                category = category,
                source = "User Approved"
            )

            result.fold(
                onSuccess = {
                    _uiState.update {
                        it.copy(
                            showAddDialog = false,
                            newKeyInput = "",
                            newValueInput = "",
                            errorMessage = null,
                            infoMessage = "Saved preference to Muskan's memory."
                        )
                    }
                },
                onFailure = { error ->
                    _uiState.update {
                        it.copy(errorMessage = error.message ?: "Failed to save memory item.")
                    }
                }
            )
        }
    }

    fun onRequestDelete(memory: MemoryEntity) {
        _uiState.update { it.copy(memoryToDelete = memory) }
    }

    fun onDismissDeleteDialog() {
        _uiState.update { it.copy(memoryToDelete = null) }
    }

    fun onConfirmDelete() {
        val toDelete = _uiState.value.memoryToDelete ?: return
        viewModelScope.launch {
            memoryManager.deleteMemory(toDelete.id)
            _uiState.update {
                it.copy(
                    memoryToDelete = null,
                    infoMessage = "Removed item from memory."
                )
            }
        }
    }

    fun onRequestClearAll() {
        _uiState.update { it.copy(showClearAllDialog = true) }
    }

    fun onDismissClearAllDialog() {
        _uiState.update { it.copy(showClearAllDialog = false) }
    }

    fun onConfirmClearAll() {
        viewModelScope.launch {
            memoryManager.clearAllMemories()
            _uiState.update {
                it.copy(
                    showClearAllDialog = false,
                    infoMessage = "Cleared all remembered context."
                )
            }
        }
    }

    fun onDismissInfoMessage() {
        _uiState.update { it.copy(infoMessage = null) }
    }
}
