package com.example.ui.screens.history

import com.example.data.local.entity.ConversationEntity

data class HistoryUiState(
    val conversations: List<ConversationEntity> = emptyList(),
    val filteredConversations: List<ConversationEntity> = emptyList(),
    val searchQuery: String = "",
    val isLoading: Boolean = false,
    val conversationToDelete: ConversationEntity? = null,
    val showClearAllDialog: Boolean = false,
    val editingConversation: ConversationEntity? = null,
    val editedTitleInput: String = ""
)
