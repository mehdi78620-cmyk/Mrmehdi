package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.GlassCardColor
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPinkGlow
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonPurpleGlow
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

data class FeatureItemData(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val neonAccent: Color,
    val glowColor: Color
)

val defaultMuskanFeatures = listOf(
    FeatureItemData("Chat", "Start conversation", Icons.Default.ChatBubble, NeonPink, NeonPinkGlow),
    FeatureItemData("Web Search", "Live online info", Icons.Default.Search, NeonCyan, Color(0x4D00E5FF)),
    FeatureItemData("Create Image", "AI visual art", Icons.Default.AutoAwesome, NeonPink, NeonPinkGlow),
    FeatureItemData("Coding", "Code & debug", Icons.Default.Code, NeonPurple, NeonPurpleGlow),
    FeatureItemData("Voice", "Realtime audio", Icons.Default.GraphicEq, NeonPink, NeonPinkGlow),
    FeatureItemData("Camera", "Visual analyze", Icons.Default.PhotoCamera, NeonCyan, Color(0x4D00E5FF)),
    FeatureItemData("Files", "PDFs & docs", Icons.Default.Description, NeonPurple, NeonPurpleGlow),
    FeatureItemData("More", "All AI tools", Icons.Default.GridView, NeonPink, NeonPinkGlow)
)

@Composable
fun FeatureCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    neonAccent: Color = NeonPink,
    glowColor: Color = NeonPinkGlow,
    onClick: () -> Unit = {}
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    // Smooth spring press animation
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.94f else 1.0f,
        animationSpec = spring(stiffness = 400f, dampingRatio = 0.75f),
        label = "card_scale"
    )
    val borderAlpha by animateFloatAsState(
        targetValue = if (isPressed) 0.9f else 0.4f,
        animationSpec = spring(stiffness = 400f),
        label = "border_alpha"
    )

    Card(
        onClick = onClick,
        interactionSource = interactionSource,
        modifier = modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .testTag("feature_card_${title.lowercase().replace(" ", "_")}"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = GlassCardColor
        ),
        border = BorderStroke(
            1.dp,
            Brush.linearGradient(
                listOf(
                    neonAccent.copy(alpha = borderAlpha),
                    Color(0x1AFFFFFF),
                    glowColor.copy(alpha = borderAlpha * 0.5f)
                )
            )
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Glowing icon container
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(neonAccent.copy(alpha = 0.16f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = neonAccent,
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Subtle neon dot accent
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(neonAccent.copy(alpha = if (isPressed) 1f else 0.6f))
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                ),
                color = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall.copy(
                    fontSize = 11.sp
                ),
                color = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

// Backwards compatibility overload
@Composable
fun FeatureCard(
    title: String,
    description: String,
    modifier: Modifier = Modifier
) {
    FeatureCard(
        title = title,
        subtitle = description,
        icon = Icons.Default.AutoAwesome,
        modifier = modifier
    )
}

