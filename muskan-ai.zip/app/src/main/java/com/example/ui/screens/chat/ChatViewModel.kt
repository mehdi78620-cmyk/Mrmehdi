package com.example.ui.screens.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.MuskanApplication
import com.example.data.api.AIStreamEvent
import com.example.data.manager.ConversationManager
import com.example.voice.SpeechRecognitionHelper
import com.example.voice.SpeechRecognitionState
import com.example.voice.TextToSpeechHelper
import com.example.voice.VoiceLanguage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

class ChatViewModel(
    private val conversationManager: ConversationManager = ConversationManager.getInstance(),
    speechRecognitionHelper: SpeechRecognitionHelper? = null,
    textToSpeechHelper: TextToSpeechHelper? = null
) : ViewModel() {

    private val speechHelper: SpeechRecognitionHelper by lazy {
        speechRecognitionHelper ?: SpeechRecognitionHelper(MuskanApplication.instance)
    }

    private val ttsHelper: TextToSpeechHelper by lazy {
        textToSpeechHelper ?: TextToSpeechHelper(MuskanApplication.instance)
    }

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    init {
        loadInitialHistory()
        observeMemoryCount()
        observeSpeechState()
        observeTtsState()
    }

    private fun observeMemoryCount() {
        viewModelScope.launch {
            conversationManager.memoryManager.getMemoryCountFlow().collect { count ->
                _uiState.update { it.copy(memoryCount = count) }
            }
        }
    }

    private fun observeSpeechState() {
        viewModelScope.launch {
            speechHelper.state.collect { state ->
                when (state) {
                    is SpeechRecognitionState.Idle -> {
                        _uiState.update { it.copy(isListening = false, voiceRmsDb = 0f) }
                    }
                    is SpeechRecognitionState.Initializing,
                    is SpeechRecognitionState.Ready -> {
                        _uiState.update { it.copy(isListening = true, voiceError = null) }
                    }
                    is SpeechRecognitionState.Listening -> {
                        _uiState.update { it.copy(isListening = true, voiceRmsDb = state.rmsDb) }
                    }
                    is SpeechRecognitionState.Recognized -> {
                        _uiState.update {
                            it.copy(
                                inputText = state.text,
                                voicePartialText = state.text,
                                isListening = !state.isFinal,
                                voiceRmsDb = if (state.isFinal) 0f else it.voiceRmsDb
                            )
                        }
                    }
                    is SpeechRecognitionState.Error -> {
                        _uiState.update {
                            it.copy(
                                isListening = false,
                                voiceError = state.message,
                                voiceRmsDb = 0f
                            )
                        }
                    }
                }
            }
        }
    }

    private fun observeTtsState() {
        viewModelScope.launch {
            ttsHelper.isSpeaking.collect { speaking ->
                val currentId = ttsHelper.currentSpeakingUtteranceId.value
                _uiState.update { state ->
                    val updatedMessages = state.messages.map { msg ->
                        msg.copy(isSpeaking = speaking && msg.id == currentId)
                    }
                    state.copy(
                        isTtsSpeaking = speaking,
                        speakingMessageId = if (speaking) currentId else null,
                        messages = updatedMessages
                    )
                }
            }
        }

        viewModelScope.launch {
            ttsHelper.currentSpeakingUtteranceId.collect { id ->
                val isSpeaking = ttsHelper.isSpeaking.value
                _uiState.update { state ->
                    val updatedMessages = state.messages.map { msg ->
                        msg.copy(isSpeaking = isSpeaking && msg.id == id)
                    }
                    state.copy(
                        speakingMessageId = id,
                        messages = updatedMessages
                    )
                }
            }
        }
    }

    private fun loadInitialHistory() {
        val domainHistory = conversationManager.getHistory()
        val initialUiMessages = domainHistory.map { item ->
            ChatUiMessage(
                id = item.id,
                text = item.content,
                isUser = item.role == com.example.data.model.MessageRole.USER
            )
        }
        _uiState.update {
            it.copy(
                conversationId = conversationManager.activeConversationId,
                conversationTitle = conversationManager.activeConversationTitle,
                messages = initialUiMessages
            )
        }
    }

    fun loadConversation(conversationId: String) {
        if (conversationId.isBlank() || conversationId == _uiState.value.conversationId) return
        viewModelScope.launch {
            val success = conversationManager.loadConversation(conversationId)
            if (success) {
                loadInitialHistory()
            }
        }
    }

    fun startNewChat() {
        viewModelScope.launch {
            stopTts()
            stopListening()
            conversationManager.startNewConversation("New Chat")
            loadInitialHistory()
            _uiState.update {
                it.copy(
                    inputText = "",
                    isLoading = false,
                    isStreaming = false,
                    errorMessage = null,
                    canRetry = false,
                    lastFailedUserMessage = null,
                    isListening = false,
                    voiceError = null
                )
            }
        }
    }

    fun onInputTextChanged(newText: String) {
        _uiState.update { it.copy(inputText = newText) }
    }

    // Native Speech Recognition control
    fun toggleListening() {
        if (_uiState.value.isListening) {
            stopListening()
        } else {
            startListening()
        }
    }

    fun startListening() {
        stopTts()
        _uiState.update {
            it.copy(
                isListening = true,
                voiceError = null,
                permissionDenied = false,
                isVoiceModeActive = true
            )
        }
        val currentLang = VoiceLanguage.fromTag(_uiState.value.voiceLanguage)
        speechHelper.setLanguage(currentLang)
        speechHelper.startListening(
            onPartialResult = { partial ->
                _uiState.update {
                    it.copy(
                        inputText = partial,
                        voicePartialText = partial
                    )
                }
            },
            onFinalResult = { final ->
                _uiState.update {
                    it.copy(
                        inputText = final,
                        voicePartialText = final,
                        isListening = false,
                        voiceRmsDb = 0f
                    )
                }
            },
            onErrorResult = { errorMsg ->
                _uiState.update {
                    it.copy(
                        isListening = false,
                        voiceError = errorMsg,
                        voiceRmsDb = 0f
                    )
                }
            }
        )
    }

    fun stopListening() {
        speechHelper.stopListening()
        _uiState.update { it.copy(isListening = false, voiceRmsDb = 0f) }
    }

    fun setVoiceLanguage(language: VoiceLanguage) {
        speechHelper.setLanguage(language)
        _uiState.update { it.copy(voiceLanguage = language.tag) }
        // If currently listening, restart with new language
        if (_uiState.value.isListening) {
            startListening()
        }
    }

    fun onPermissionDenied() {
        _uiState.update {
            it.copy(
                permissionDenied = true,
                isListening = false,
                voiceError = "Microphone permission is required for voice conversation."
            )
        }
    }

    fun clearVoiceError() {
        _uiState.update { it.copy(voiceError = null, permissionDenied = false) }
    }

    // Native Text-to-Speech control
    fun toggleTtsForMessage(messageId: String, text: String) {
        if (_uiState.value.speakingMessageId == messageId && _uiState.value.isTtsSpeaking) {
            stopTts()
        } else {
            val preferredLang = VoiceLanguage.fromTag(_uiState.value.voiceLanguage)
            ttsHelper.speak(
                text = text,
                utteranceId = messageId,
                preferredLanguage = preferredLang
            )
        }
    }

    fun stopTts() {
        ttsHelper.stop()
    }

    fun toggleAutoTts() {
        _uiState.update { it.copy(autoTtsEnabled = !it.autoTtsEnabled) }
    }

    fun setAttachment(uri: android.net.Uri, name: String, type: String) {
        _uiState.update { it.copy(attachmentUri = uri, attachmentName = name, attachmentType = type) }
    }

    fun clearAttachment() {
        _uiState.update { it.copy(attachmentUri = null, attachmentName = null, attachmentType = null) }
    }

    fun sendMessage(prompt: String = _uiState.value.inputText) {
        val currentState = _uiState.value
        val userPrompt = prompt.trim()
        val attachmentUri = currentState.attachmentUri
        val attachmentName = currentState.attachmentName
        val attachmentType = currentState.attachmentType

        if (userPrompt.isEmpty() && attachmentUri == null) return
        if (currentState.isLoading || currentState.isStreaming) return

        val displayPrompt = if (userPrompt.isEmpty() && attachmentName != null) {
            "Shared attachment: $attachmentName"
        } else {
            userPrompt
        }

        // Stop any active speech or TTS before sending
        stopListening()
        stopTts()

        // 1. Add user turn to conversation manager
        val userTurn = conversationManager.addUserMessage(displayPrompt)
        val userUiMessage = ChatUiMessage(
            id = userTurn.id,
            text = displayPrompt,
            isUser = true,
            attachmentUri = attachmentUri,
            attachmentName = attachmentName,
            attachmentType = attachmentType
        )

        // 2. Prepare placeholder for incoming assistant turn
        val aiMessageId = UUID.randomUUID().toString()
        val placeholderAiMessage = ChatUiMessage(
            id = aiMessageId,
            text = "",
            isUser = false,
            isStreaming = true
        )

        _uiState.update { state ->
            state.copy(
                conversationId = conversationManager.activeConversationId,
                conversationTitle = conversationManager.activeConversationTitle,
                messages = state.messages + userUiMessage + placeholderAiMessage,
                inputText = "",
                voicePartialText = "",
                attachmentUri = null,
                attachmentName = null,
                attachmentType = null,
                isLoading = true,
                isStreaming = false,
                errorMessage = null,
                canRetry = false,
                lastFailedUserMessage = displayPrompt
            )
        }

        // 3. Dispatch to backend via ConversationManager and stream response
        viewModelScope.launch {
            val textAccumulator = StringBuilder()

            conversationManager.streamResponse().collect { event ->
                when (event) {
                    is AIStreamEvent.Chunk -> {
                        textAccumulator.append(event.text)
                        _uiState.update { state ->
                            val updatedList = state.messages.map { msg ->
                                if (msg.id == aiMessageId) {
                                    msg.copy(
                                        text = textAccumulator.toString(),
                                        isStreaming = true
                                    )
                                } else {
                                    msg
                                }
                            }
                            state.copy(
                                messages = updatedList,
                                isLoading = false,
                                isStreaming = true,
                                errorMessage = null
                            )
                        }
                    }

                    is AIStreamEvent.Complete -> {
                        val finalText = if (event.fullText.isNotEmpty()) event.fullText else textAccumulator.toString()
                        conversationManager.recordAiResponse(aiMessageId, finalText)

                        _uiState.update { state ->
                            val updatedList = state.messages.map { msg ->
                                if (msg.id == aiMessageId) {
                                    msg.copy(
                                        text = finalText,
                                        isStreaming = false,
                                        isError = false
                                    )
                                } else {
                                    msg
                                }
                            }
                            state.copy(
                                conversationTitle = conversationManager.activeConversationTitle,
                                messages = updatedList,
                                isLoading = false,
                                isStreaming = false,
                                canRetry = false,
                                lastFailedUserMessage = null
                            )
                        }

                        // Text-to-Speech for AI responses when voice mode is active or auto-TTS is enabled
                        if (_uiState.value.autoTtsEnabled || _uiState.value.isVoiceModeActive) {
                            val preferredLang = VoiceLanguage.fromTag(_uiState.value.voiceLanguage)
                            ttsHelper.speak(
                                text = finalText,
                                utteranceId = aiMessageId,
                                preferredLanguage = preferredLang
                            )
                        }
                    }

                    is AIStreamEvent.Error -> {
                        conversationManager.removeLastIfFailed(aiMessageId)

                        _uiState.update { state ->
                            val updatedList = state.messages.mapNotNull { msg ->
                                if (msg.id == aiMessageId) {
                                    if (textAccumulator.isNotEmpty()) {
                                        msg.copy(
                                            text = textAccumulator.toString(),
                                            isStreaming = false,
                                            isError = true
                                        )
                                    } else {
                                        null
                                    }
                                } else {
                                    msg
                                }
                            }
                            state.copy(
                                messages = updatedList,
                                isLoading = false,
                                isStreaming = false,
                                errorMessage = event.userFriendlyMessage,
                                canRetry = true,
                                lastFailedUserMessage = userPrompt
                            )
                        }
                    }
                }
            }
        }
    }

    fun retry() {
        val failedPrompt = _uiState.value.lastFailedUserMessage
        if (!failedPrompt.isNullOrBlank()) {
            _uiState.update { it.copy(errorMessage = null, canRetry = false) }
            sendMessage(failedPrompt)
        }
    }

    fun clearError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    fun resetChat() {
        startNewChat()
    }

    override fun onCleared() {
        super.onCleared()
        speechHelper.destroy()
        ttsHelper.shutdown()
    }
}
