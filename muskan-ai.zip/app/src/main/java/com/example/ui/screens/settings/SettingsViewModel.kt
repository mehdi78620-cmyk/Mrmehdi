package com.example.ui.screens.settings

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.config.AppSettings
import com.example.data.repository.SettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SettingsUiState(
    val settings: AppSettings = AppSettings(),
    val isSaving: Boolean = false,
    val statusMessage: String? = null,
    val showClearMemoryDialog: Boolean = false
)

class SettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = SettingsRepository.getInstance(application)

    private val _uiState = MutableStateFlow(SettingsUiState(settings = repository.getSettings()))
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            repository.settingsFlow.collect { settings ->
                _uiState.update { it.copy(settings = settings) }
            }
        }
    }

    // Response Settings
    fun updateResponseSettings(style: String, temperature: Float, language: String) {
        repository.updateResponseSettings(style, temperature, language)
        showStatus("AI Response settings updated successfully.")
    }

    // Voice Settings
    fun updateVoiceSettings(voiceEnabled: Boolean, speechLang: String, ttsEnabled: Boolean, speed: Float, pitch: Float) {
        repository.updateVoiceSettings(voiceEnabled, speechLang, ttsEnabled, speed, pitch)
        showStatus("Voice & speech settings updated successfully.")
    }

    // Personalization
    fun updatePersonalization(assistantName: String, userName: String, instructions: String, style: String) {
        repository.updatePersonalization(assistantName, userName, instructions, style)
        showStatus("Personalization settings updated successfully.")
    }

    // Memory Settings
    fun updateMemoryEnabled(enabled: Boolean) {
        repository.updateMemorySettings(enabled)
        showStatus(if (enabled) "Memory enabled" else "Memory disabled")
    }

    fun requestClearAllMemory() {
        _uiState.update { it.copy(showClearMemoryDialog = true) }
    }

    fun dismissClearMemoryDialog() {
        _uiState.update { it.copy(showClearMemoryDialog = false) }
    }

    // Appearance Settings
    fun updateAppearance(darkTheme: Boolean, neonIntensity: Float, animations: Boolean, reduceAnim: Boolean) {
        repository.updateAppearance(darkTheme, neonIntensity, animations, reduceAnim)
        showStatus("Appearance settings updated successfully.")
    }

    fun dismissStatus() {
        _uiState.update { it.copy(statusMessage = null) }
    }

    private fun showStatus(message: String) {
        _uiState.update { it.copy(statusMessage = message) }
    }
}
