package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.core.content.FileProvider
import coil.compose.AsyncImage
import java.io.File
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.R
import com.example.ui.screens.chat.ChatUiMessage
import com.example.ui.screens.chat.ChatViewModel
import com.example.ui.theme.DeepNavyBackground
import com.example.ui.theme.GlassCardBorder
import com.example.ui.theme.GlassCardColor
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanGlow
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPinkGlow
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonPurpleGlow
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.voice.VoiceLanguage

@Composable
fun ChatScreen(
    modifier: Modifier = Modifier,
    conversationId: String? = null,
    startVoiceImmediately: Boolean = false,
    onBackClick: () -> Unit = {},
    onNavigateToSettings: () -> Unit = {},
    onNavigateToHistory: () -> Unit = {},
    onNavigateToMemory: () -> Unit = {},
    viewModel: ChatViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val listState = rememberLazyListState()
    val context = LocalContext.current

    // Permission launcher for microphone
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.startListening()
        } else {
            viewModel.onPermissionDenied()
        }
    }

    var tempCameraUri by remember { mutableStateOf<Uri?>(null) }

    val takePictureLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success ->
        if (success && tempCameraUri != null) {
            viewModel.setAttachment(tempCameraUri!!, "Captured_Photo.jpg", "image")
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            try {
                val timeStamp = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.getDefault()).format(java.util.Date())
                val storageDir = context.getExternalFilesDir(android.os.Environment.DIRECTORY_PICTURES) ?: context.cacheDir
                val imageFile = File.createTempFile("JPEG_${timeStamp}_", ".jpg", storageDir)
                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", imageFile)
                tempCameraUri = uri
                takePictureLauncher.launch(uri)
            } catch (e: Exception) {
                Toast.makeText(context, "Error setting up camera file: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(context, "Camera permission is required to capture photos.", Toast.LENGTH_SHORT).show()
        }
    }

    val filePickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            val mimeType = context.contentResolver.getType(uri) ?: "*/*"
            var fileName = "Document_File"
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIdx != -1) {
                        fileName = cursor.getString(nameIdx) ?: "Document_File"
                    }
                }
            }

            if (mimeType.startsWith("image/") || mimeType.contains("pdf") || mimeType.contains("text") || mimeType.contains("document") || mimeType.contains("msword") || mimeType.contains("officedocument")) {
                val type = if (mimeType.startsWith("image/")) "image" else "document"
                viewModel.setAttachment(uri, fileName, type)
            } else {
                Toast.makeText(context, "Unsupported file type ($mimeType). Please select an image, PDF, or document.", Toast.LENGTH_LONG).show()
            }
        }
    }

    val onCameraClick: () -> Unit = {
        val hasPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED

        if (hasPermission) {
            try {
                val timeStamp = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.getDefault()).format(java.util.Date())
                val storageDir = context.getExternalFilesDir(android.os.Environment.DIRECTORY_PICTURES) ?: context.cacheDir
                val imageFile = File.createTempFile("JPEG_${timeStamp}_", ".jpg", storageDir)
                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", imageFile)
                tempCameraUri = uri
                takePictureLauncher.launch(uri)
            } catch (e: Exception) {
                Toast.makeText(context, "Error setting up camera: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
        } else {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    val onFileClick: () -> Unit = {
        filePickerLauncher.launch(arrayOf("image/*", "application/pdf", "text/*", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"))
    }

    val onMicClick: () -> Unit = {
        val hasPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (hasPermission) {
            viewModel.toggleListening()
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    LaunchedEffect(conversationId) {
        if (!conversationId.isNullOrBlank()) {
            viewModel.loadConversation(conversationId)
        }
    }

    // Auto-start voice if entered via voice route
    LaunchedEffect(startVoiceImmediately) {
        if (startVoiceImmediately) {
            val hasPermission = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
            if (hasPermission) {
                viewModel.startListening()
            } else {
                permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    // Auto-scroll to bottom when messages are added or streaming updates arrive
    val totalItems = uiState.messages.size
    val lastItemLength = uiState.messages.lastOrNull()?.text?.length ?: 0

    LaunchedEffect(totalItems, lastItemLength, uiState.isLoading) {
        if (totalItems > 0) {
            val targetIndex = if (uiState.isLoading) totalItems else totalItems - 1
            if (targetIndex >= 0) {
                listState.animateScrollToItem(targetIndex)
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DeepNavyBackground)
            .drawBehind {
                // Top subtle glow
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            NeonPurpleGlow.copy(alpha = 0.22f),
                            Color.Transparent
                        ),
                        center = Offset(size.width * 0.5f, size.height * 0.12f),
                        radius = size.width * 0.7f
                    )
                )
                // Bottom subtle glow
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            NeonPinkGlow.copy(alpha = 0.16f),
                            Color.Transparent
                        ),
                        center = Offset(size.width * 0.8f, size.height * 0.9f),
                        radius = size.width * 0.6f
                    )
                )
            }
            .imePadding()
            .navigationBarsPadding()
            .testTag("muskan_chat_screen")
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // 1. TOP APP BAR
            ChatTopAppBar(
                conversationTitle = uiState.conversationTitle,
                memoryCount = uiState.memoryCount,
                autoTtsEnabled = uiState.autoTtsEnabled,
                onToggleAutoTts = { viewModel.toggleAutoTts() },
                onBackClick = onBackClick,
                onNewChatClick = { viewModel.startNewChat() },
                onHistoryClick = onNavigateToHistory,
                onMemoryClick = onNavigateToMemory,
                onSettingsClick = onNavigateToSettings
            )

            // 2. CHAT MESSAGES LIST
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(uiState.messages, key = { it.id }) { msg ->
                    if (msg.isUser) {
                        UserMessageBubble(message = msg)
                    } else {
                        AIMessageBubble(
                            message = msg,
                            onSpeakClick = {
                                viewModel.toggleTtsForMessage(msg.id, msg.text)
                            }
                        )
                    }
                }

                // Typing indicator when waiting for initial stream tokens
                if (uiState.isLoading) {
                    item(key = "typing_indicator") {
                        TypingIndicatorBubble()
                    }
                }

                // Error State Card with Retry Action
                if (uiState.errorMessage != null) {
                    item(key = "chat_error_banner") {
                        ChatErrorBanner(
                            errorMessage = uiState.errorMessage ?: "Failed to connect",
                            canRetry = uiState.canRetry,
                            onRetry = { viewModel.retry() },
                            onDismiss = { viewModel.clearError() },
                            onConfigureProvider = onNavigateToSettings
                        )
                    }
                }

                // Voice Error Notice Banner
                if (uiState.voiceError != null) {
                    item(key = "voice_error_banner") {
                        VoiceErrorBanner(
                            errorMessage = uiState.voiceError ?: "Voice recognition error",
                            onDismiss = { viewModel.clearVoiceError() },
                            onRetry = onMicClick
                        )
                    }
                }

                // Microphone Permission Denied Notice
                if (uiState.permissionDenied) {
                    item(key = "permission_denied_banner") {
                        PermissionDeniedBanner(
                            onGrantClick = {
                                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                    data = Uri.fromParts("package", context.packageName, null)
                                }
                                try {
                                    context.startActivity(intent)
                                } catch (_: Exception) {
                                    permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }
                            },
                            onDismiss = { viewModel.clearVoiceError() }
                        )
                    }
                }
            }

            // Quick multilingual suggestions chips
            MultilingualSuggestionRow(
                onSuggestionClick = { prompt ->
                    viewModel.sendMessage(prompt)
                }
            )

            // 3. MESSAGE INPUT & MICROPHONE DOCK
            ChatBottomInputDock(
                inputText = uiState.inputText,
                isBusy = uiState.isLoading || uiState.isStreaming,
                isListening = uiState.isListening,
                voiceRmsDb = uiState.voiceRmsDb,
                voiceLanguage = uiState.voiceLanguage,
                attachmentUri = uiState.attachmentUri,
                attachmentName = uiState.attachmentName,
                attachmentType = uiState.attachmentType,
                onInputChange = { viewModel.onInputTextChanged(it) },
                onSend = { viewModel.sendMessage() },
                onMicClick = onMicClick,
                onLanguageSelect = { viewModel.setVoiceLanguage(it) },
                onStopListening = { viewModel.stopListening() },
                onCameraClick = onCameraClick,
                onFileClick = onFileClick,
                onRemoveAttachment = { viewModel.clearAttachment() }
            )
        }
    }
}

@Composable
private fun ChatTopAppBar(
    conversationTitle: String,
    memoryCount: Int,
    autoTtsEnabled: Boolean,
    onToggleAutoTts: () -> Unit,
    onBackClick: () -> Unit,
    onNewChatClick: () -> Unit,
    onHistoryClick: () -> Unit,
    onMemoryClick: () -> Unit,
    onSettingsClick: () -> Unit = {}
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0x66080914))
            .border(width = 0.5.dp, color = GlassCardBorder, shape = RoundedCornerShape(0.dp))
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Back button
        IconButton(
            onClick = onBackClick,
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(GlassCardColor)
                .border(1.dp, GlassCardBorder, CircleShape)
                .testTag("chat_back_button")
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back",
                tint = TextPrimary,
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        // Muskan AI Avatar in Top Bar
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .border(
                    width = 1.5.dp,
                    brush = Brush.sweepGradient(listOf(NeonPink, NeonPurple, NeonPink)),
                    shape = CircleShape
                )
                .padding(2.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_muskan_avatar),
                contentDescription = "Muskan AI",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape)
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        // Title and Dynamic Status/Conversation name
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "Muskan AI",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    ),
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "❤️", fontSize = 11.sp)
            }
            Text(
                text = if (conversationTitle.isNotBlank() && conversationTitle != "New Chat" && conversationTitle != "Muskan AI")
                    conversationTitle
                else
                    "Voice Enabled • Hindi • Hinglish",
                style = MaterialTheme.typography.bodySmall.copy(
                    fontSize = 11.sp
                ),
                color = NeonPink.copy(alpha = 0.9f),
                maxLines = 1,
                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
            )
        }

        // Auto-TTS Toggle Button
        IconButton(
            onClick = onToggleAutoTts,
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(if (autoTtsEnabled) NeonCyan.copy(alpha = 0.18f) else GlassCardColor)
                .border(1.dp, if (autoTtsEnabled) NeonCyan.copy(alpha = 0.6f) else GlassCardBorder, CircleShape)
                .testTag("chat_tts_toggle_button")
        ) {
            Icon(
                imageVector = if (autoTtsEnabled) Icons.AutoMirrored.Filled.VolumeUp else Icons.Default.VolumeOff,
                contentDescription = if (autoTtsEnabled) "Auto-TTS Enabled" else "Auto-TTS Disabled",
                tint = if (autoTtsEnabled) NeonCyan else TextMuted,
                modifier = Modifier.size(17.dp)
            )
        }

        Spacer(modifier = Modifier.width(4.dp))

        // Memory / Context Button with badge
        Box {
            IconButton(
                onClick = onMemoryClick,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(GlassCardColor)
                    .border(1.dp, GlassCardBorder, CircleShape)
                .testTag("chat_memory_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Psychology,
                    contentDescription = "Memory Preferences",
                    tint = if (memoryCount > 0) NeonPurple else TextSecondary,
                    modifier = Modifier.size(18.dp)
                )
            }
            if (memoryCount > 0) {
                Box(
                    modifier = Modifier
                        .size(14.dp)
                        .align(Alignment.TopEnd)
                        .clip(CircleShape)
                        .background(NeonPink),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (memoryCount > 9) "9+" else memoryCount.toString(),
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }

        Spacer(modifier = Modifier.width(4.dp))

        // History button
        IconButton(
            onClick = onHistoryClick,
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(GlassCardColor)
                .border(1.dp, GlassCardBorder, CircleShape)
                .testTag("chat_history_button")
        ) {
            Icon(
                imageVector = Icons.Default.History,
                contentDescription = "Chat History",
                tint = TextSecondary,
                modifier = Modifier.size(18.dp)
            )
        }

        Spacer(modifier = Modifier.width(4.dp))

        // New Chat button
        IconButton(
            onClick = onNewChatClick,
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(NeonPink.copy(alpha = 0.2f))
                .border(1.dp, NeonPink.copy(alpha = 0.6f), CircleShape)
                .testTag("chat_new_button")
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "New Conversation",
                tint = NeonPink,
                modifier = Modifier.size(18.dp)
            )
        }

        Spacer(modifier = Modifier.width(4.dp))

        // Settings / AI Provider button
        IconButton(
            onClick = onSettingsClick,
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(GlassCardColor)
                .border(1.dp, GlassCardBorder, CircleShape)
                .testTag("chat_settings_button")
        ) {
            Icon(
                imageVector = Icons.Default.Settings,
                contentDescription = "AI Provider Settings",
                tint = TextSecondary,
                modifier = Modifier.size(17.dp)
            )
        }
    }
}

@Composable
private fun MultilingualSuggestionRow(
    onSuggestionClick: (String) -> Unit
) {
    val suggestions = listOf(
        "Kaise ho aap? ❤️",
        "हिंदी में कविता सुनाओ",
        "Explain quantum computing simply",
        "Meri help kar sakti ho?"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        suggestions.forEach { prompt ->
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0x1AFFFFFF))
                    .border(0.8.dp, GlassCardBorder, RoundedCornerShape(16.dp))
                    .clickable { onSuggestionClick(prompt) }
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = prompt,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                )
            }
        }
    }
}

@Composable
private fun UserMessageBubble(message: ChatUiMessage) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("user_message_bubble"),
        horizontalArrangement = Arrangement.End
    ) {
        Column(
            horizontalAlignment = Alignment.End,
            modifier = Modifier.widthIn(max = 290.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(
                        RoundedCornerShape(
                            topStart = 18.dp,
                            topEnd = 4.dp,
                            bottomStart = 18.dp,
                            bottomEnd = 18.dp
                        )
                    )
                    .background(
                        brush = Brush.linearGradient(
                            listOf(NeonPink, Color(0xFFC026D3))
                        )
                    )
                    .border(
                        1.dp,
                        Color.White.copy(alpha = 0.25f),
                        RoundedCornerShape(
                            topStart = 18.dp,
                            topEnd = 4.dp,
                            bottomStart = 18.dp,
                            bottomEnd = 18.dp
                        )
                    )
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Column {
                    if (message.text.isNotBlank()) {
                        Text(
                            text = message.text,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontSize = 14.sp,
                                lineHeight = 20.sp,
                                fontWeight = FontWeight.Normal
                            ),
                            color = Color.White
                        )
                    }

                    if (message.attachmentUri != null) {
                        if (message.text.isNotBlank()) {
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                        if (message.attachmentType == "image") {
                            AsyncImage(
                                model = message.attachmentUri,
                                contentDescription = "Attached Image",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(200.dp, 150.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .border(1.dp, Color.White.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                            )
                        } else {
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0x33000000))
                                    .padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AttachFile,
                                    contentDescription = null,
                                    tint = NeonCyan,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = message.attachmentName ?: "Attached Document",
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp, color = Color.White),
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(3.dp))

            Text(
                text = message.timestamp,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 10.sp
                ),
                color = TextMuted,
                modifier = Modifier.padding(end = 4.dp)
            )
        }
    }
}

@Composable
private fun AIMessageBubble(
    message: ChatUiMessage,
    onSpeakClick: () -> Unit = {}
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("ai_message_bubble"),
        horizontalArrangement = Arrangement.Start
    ) {
        // Mini Avatar on left of AI message
        Box(
            modifier = Modifier
                .padding(top = 4.dp, end = 8.dp)
                .size(28.dp)
                .clip(CircleShape)
                .border(1.dp, NeonPink, CircleShape)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_muskan_avatar),
                contentDescription = "Muskan AI",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }

        Column(
            horizontalAlignment = Alignment.Start,
            modifier = Modifier.widthIn(max = 290.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(
                        RoundedCornerShape(
                            topStart = 4.dp,
                            topEnd = 18.dp,
                            bottomStart = 18.dp,
                            bottomEnd = 18.dp
                        )
                    )
                    .background(Color(0x2EFFFFFF))
                    .border(
                        1.dp,
                        Brush.linearGradient(
                            listOf(
                                if (message.isError) Color(0xFFEF4444) else NeonPurple.copy(alpha = 0.5f),
                                GlassCardBorder,
                                NeonPink.copy(alpha = 0.3f)
                            )
                        ),
                        RoundedCornerShape(
                            topStart = 4.dp,
                            topEnd = 18.dp,
                            bottomStart = 18.dp,
                            bottomEnd = 18.dp
                        )
                    )
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Column {
                    Text(
                        text = message.text.ifEmpty { "..." },
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontSize = 14.sp,
                            lineHeight = 20.sp,
                            fontWeight = FontWeight.Normal
                        ),
                        color = TextPrimary
                    )

                    // Speaking active indicator
                    if (message.isSpeaking) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(NeonPink.copy(alpha = 0.15f))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.GraphicEq,
                                contentDescription = null,
                                tint = NeonPink,
                                modifier = Modifier.size(13.dp)
                            )
                            Text(
                                text = "Muskan is speaking...",
                                fontSize = 11.sp,
                                color = NeonPink,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    // Streaming pulsing indicator line
                    if (message.isStreaming) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            val infiniteTransition = rememberInfiniteTransition(label = "pulse_stream")
                            val pulseAlpha by infiniteTransition.animateFloat(
                                initialValue = 0.3f,
                                targetValue = 1f,
                                animationSpec = infiniteRepeatable(
                                    animation = tween(400, easing = LinearEasing),
                                    repeatMode = RepeatMode.Reverse
                                ),
                                label = "streaming_cursor"
                            )
                            Box(
                                modifier = Modifier
                                    .size(8.dp, 14.dp)
                                    .background(NeonPink.copy(alpha = pulseAlpha), RoundedCornerShape(2.dp))
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(2.dp))

            // Bottom bar with timestamp and Text-to-Speech speaker button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 4.dp, end = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = message.timestamp,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 10.sp
                    ),
                    color = TextMuted
                )

                if (!message.isStreaming && message.text.isNotBlank()) {
                    IconButton(
                        onClick = onSpeakClick,
                        modifier = Modifier
                            .size(26.dp)
                            .testTag("tts_button_${message.id}")
                    ) {
                        Icon(
                            imageVector = if (message.isSpeaking) Icons.Default.Stop else Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = if (message.isSpeaking) "Stop voice" else "Read aloud with Text-to-Speech",
                            tint = if (message.isSpeaking) NeonPink else TextSecondary,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TypingIndicatorBubble() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("typing_indicator"),
        horizontalArrangement = Arrangement.Start,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .padding(end = 8.dp)
                .size(28.dp)
                .clip(CircleShape)
                .border(1.dp, NeonPink, CircleShape)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_muskan_avatar),
                contentDescription = "Muskan AI",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }

        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0x22FFFFFF))
                .border(1.dp, GlassCardBorder, RoundedCornerShape(16.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val infiniteTransition = rememberInfiniteTransition(label = "dots_transition")

                val dot1Alpha by infiniteTransition.animateFloat(
                    initialValue = 0.3f,
                    targetValue = 1f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(600, easing = LinearEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "dot1"
                )

                val dot2Alpha by infiniteTransition.animateFloat(
                    initialValue = 0.3f,
                    targetValue = 1f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(600, delayMillis = 200, easing = LinearEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "dot2"
                )

                val dot3Alpha by infiniteTransition.animateFloat(
                    initialValue = 0.3f,
                    targetValue = 1f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(600, delayMillis = 400, easing = LinearEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "dot3"
                )

                Box(
                    modifier = Modifier
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(NeonPink.copy(alpha = dot1Alpha))
                )
                Box(
                    modifier = Modifier
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(NeonPink.copy(alpha = dot2Alpha))
                )
                Box(
                    modifier = Modifier
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(NeonPink.copy(alpha = dot3Alpha))
                )

                Spacer(modifier = Modifier.width(4.dp))

                Text(
                    text = "Muskan is thinking...",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 11.sp
                    ),
                    color = TextSecondary
                )
            }
        }
    }
}

@Composable
private fun VoiceErrorBanner(
    errorMessage: String,
    onDismiss: () -> Unit,
    onRetry: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0x2E7F1D1D))
            .border(1.dp, Color(0x66EF4444), RoundedCornerShape(16.dp))
            .padding(12.dp)
            .testTag("voice_error_banner")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.MicOff,
                    contentDescription = "Voice notice",
                    tint = Color(0xFFF87171),
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = errorMessage,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontSize = 12.sp,
                        color = Color(0xFFFCA5A5)
                    )
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(
                    onClick = onRetry,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text("Try Again", color = NeonPink, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                TextButton(
                    onClick = onDismiss,
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)
                ) {
                    Text("Dismiss", color = TextMuted, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun PermissionDeniedBanner(
    onGrantClick: () -> Unit,
    onDismiss: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0x333730A3))
            .border(1.dp, NeonPurple.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
            .padding(14.dp)
            .testTag("permission_denied_banner")
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Mic,
                    contentDescription = null,
                    tint = NeonPurple,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Microphone Permission Required",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Muskan AI needs microphone access to listen to your voice and converse with you in Hindi & English.",
                style = MaterialTheme.typography.bodySmall.copy(
                    fontSize = 12.sp,
                    color = TextSecondary
                )
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onDismiss) {
                    Text("Not now", color = TextMuted, fontSize = 12.sp)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = onGrantClick,
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text("Grant Permission", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun ChatErrorBanner(
    errorMessage: String,
    canRetry: Boolean,
    onRetry: () -> Unit,
    onDismiss: () -> Unit,
    onConfigureProvider: () -> Unit = {}
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0x2E7F1D1D))
            .border(1.dp, Color(0x66EF4444), RoundedCornerShape(16.dp))
            .padding(14.dp)
            .testTag("chat_error_banner")
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.WarningAmber,
                    contentDescription = "Error",
                    tint = Color(0xFFF87171),
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Connection Notice",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFFCA5A5)
                    )
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = errorMessage,
                style = MaterialTheme.typography.bodySmall.copy(
                    fontSize = 12.sp,
                    lineHeight = 17.sp,
                    color = TextSecondary
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(
                    onClick = onDismiss,
                    colors = ButtonDefaults.textButtonColors(contentColor = TextMuted)
                ) {
                    Text("Dismiss", fontSize = 12.sp)
                }

                if (errorMessage.contains("Provider", ignoreCase = true) ||
                    errorMessage.contains("API key", ignoreCase = true) ||
                    errorMessage.contains("Settings", ignoreCase = true)
                ) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = onConfigureProvider,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NeonPurple
                        ),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("chat_configure_provider_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Configure",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }

                if (canRetry) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = onRetry,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NeonPink
                        ),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("chat_retry_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Retry",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ChatBottomInputDock(
    inputText: String,
    isBusy: Boolean,
    isListening: Boolean,
    voiceRmsDb: Float,
    voiceLanguage: String,
    attachmentUri: Uri?,
    attachmentName: String?,
    attachmentType: String?,
    onInputChange: (String) -> Unit,
    onSend: () -> Unit,
    onMicClick: () -> Unit,
    onLanguageSelect: (VoiceLanguage) -> Unit,
    onStopListening: () -> Unit,
    onCameraClick: () -> Unit,
    onFileClick: () -> Unit,
    onRemoveAttachment: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0x55080914))
            .border(width = 0.5.dp, color = GlassCardBorder, shape = RoundedCornerShape(0.dp))
    ) {
        // Attachment Preview Banner if present
        if (attachmentUri != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 6.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0x33FFFFFF))
                    .border(1.dp, GlassCardBorder, RoundedCornerShape(12.dp))
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    if (attachmentType == "image") {
                        AsyncImage(
                            model = attachmentUri,
                            contentDescription = "Attachment Preview",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                        )
                    } else {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(NeonPurple.copy(alpha = 0.3f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AttachFile,
                                contentDescription = null,
                                tint = NeonCyan,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = attachmentName ?: "Attachment",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            ),
                            maxLines = 1,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                        )
                        Text(
                            text = if (attachmentType == "image") "Ready to send image" else "Ready to send document",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 10.sp,
                                color = TextSecondary
                            )
                        )
                    }
                }

                IconButton(
                    onClick = onRemoveAttachment,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Remove attachment",
                        tint = TextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        // Active Listening Banner above input
        AnimatedVisibility(
            visible = isListening,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0x33101328))
                    .border(0.5.dp, NeonPink.copy(alpha = 0.4f), RoundedCornerShape(0.dp))
                .padding(horizontal = 14.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Pulsing animated sound wave indicator
                    val infiniteTransition = rememberInfiniteTransition(label = "wave_pulse")
                    val waveScale by infiniteTransition.animateFloat(
                        initialValue = 0.7f,
                        targetValue = 1.3f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(500, easing = LinearEasing),
                            repeatMode = RepeatMode.Reverse
                        ),
                        label = "wave_scale"
                    )

                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .graphicsLayer { scaleX = waveScale; scaleY = waveScale }
                            .clip(CircleShape)
                            .background(NeonPink)
                    )

                    Text(
                        text = "Listening... बोलिए, Muskan सुन रही है",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White
                        )
                    )
                }

                // Language pills: Hindi, Hinglish, English
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    VoiceLanguage.entries.forEach { lang ->
                        val isSelected = voiceLanguage.equals(lang.tag, ignoreCase = true)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) NeonPink else Color(0x22FFFFFF))
                                .border(
                                    0.5.dp,
                                    if (isSelected) NeonPink else GlassCardBorder,
                                    RoundedCornerShape(10.dp)
                                )
                                .clickable { onLanguageSelect(lang) }
                                .padding(horizontal = 7.dp, vertical = 3.dp)
                                .testTag("voice_lang_${lang.name.lowercase()}")
                        ) {
                            Text(
                                text = lang.displayName,
                                fontSize = 10.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) Color.White else TextSecondary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    IconButton(
                        onClick = onStopListening,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Stop,
                            contentDescription = "Stop Listening",
                            tint = NeonPink,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }

        // Message Input Row with Animated Microphone Button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Attachment Button with Dropdown Menu
            Box {
                IconButton(
                    onClick = { showMenu = true },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(GlassCardColor)
                        .border(1.dp, GlassCardBorder, CircleShape)
                        .testTag("chat_attachment_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.CameraAlt,
                        contentDescription = "Attach photo or file",
                        tint = NeonPink,
                        modifier = Modifier.size(20.dp)
                    )
                }

                androidx.compose.material3.DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = { showMenu = false },
                    modifier = Modifier.background(DeepNavyBackground)
                ) {
                    androidx.compose.material3.DropdownMenuItem(
                        text = { Text("Take Photo", color = TextPrimary) },
                        onClick = {
                            showMenu = false
                            onCameraClick()
                        },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.CameraAlt, contentDescription = null, tint = NeonPink)
                        },
                        modifier = Modifier.testTag("menu_take_photo")
                    )
                    androidx.compose.material3.DropdownMenuItem(
                        text = { Text("Choose File / Document", color = TextPrimary) },
                        onClick = {
                            showMenu = false
                            onFileClick()
                        },
                        leadingIcon = {
                            Icon(imageVector = Icons.Default.AttachFile, contentDescription = null, tint = NeonCyan)
                        },
                        modifier = Modifier.testTag("menu_choose_file")
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Message Input Box
            Row(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(26.dp))
                    .background(Color(0x22FFFFFF))
                    .border(
                        1.dp,
                        if (isListening) NeonPink.copy(alpha = 0.8f) else GlassCardBorder,
                        RoundedCornerShape(26.dp)
                    )
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier.weight(1f),
                    contentAlignment = Alignment.CenterStart
                ) {
                    if (inputText.isEmpty()) {
                        Text(
                            text = if (isListening) "Listening to your voice..." else "Message Muskan AI...",
                            color = if (isListening) NeonCyan else TextSecondary.copy(alpha = 0.7f),
                            fontSize = 14.sp
                        )
                    }
                    BasicTextField(
                        value = inputText,
                        onValueChange = onInputChange,
                        textStyle = MaterialTheme.typography.bodyMedium.copy(
                            color = TextPrimary,
                            fontSize = 14.sp
                        ),
                        cursorBrush = SolidColor(NeonPink),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("chat_input_field")
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Send Button inside input
                IconButton(
                    onClick = onSend,
                    enabled = inputText.isNotBlank() && !isBusy,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(
                            if (inputText.isNotBlank() && !isBusy) NeonPink else Color(0x1AFFFFFF)
                        )
                        .testTag("chat_send_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Send",
                        tint = if (inputText.isNotBlank() && !isBusy) Color.White else TextMuted,
                        modifier = Modifier.size(17.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            // Animated Glowing Microphone Button
            val micInteractionSource = remember { MutableInteractionSource() }

            // Infinite breathing pulse
            val infiniteTransition = rememberInfiniteTransition(label = "mic_glow_pulse")
            val pulseGlow by infiniteTransition.animateFloat(
                initialValue = 0.5f,
                targetValue = 1.0f,
                animationSpec = infiniteRepeatable(
                    animation = tween(durationMillis = if (isListening) 800 else 1800, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "pulse_glow"
            )

            // Dynamic scale modulated by active listening RMS dB
            val dynamicScale = if (isListening) {
                1.0f + (voiceRmsDb.coerceIn(0f, 1f) * 0.22f)
            } else {
                1.0f
            }

            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clickable(
                        interactionSource = micInteractionSource,
                        indication = null,
                        onClick = onMicClick
                    )
                    .graphicsLayer {
                        scaleX = dynamicScale
                        scaleY = dynamicScale
                    }
                    .drawBehind {
                        val glowRadius = size.minDimension * (if (isListening) 0.85f else 0.65f)
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    if (isListening) NeonPinkGlow.copy(alpha = pulseGlow) else NeonPinkGlow.copy(alpha = pulseGlow * 0.7f),
                                    if (isListening) NeonCyanGlow.copy(alpha = pulseGlow * 0.5f) else NeonPurpleGlow.copy(alpha = pulseGlow * 0.4f),
                                    Color.Transparent
                                )
                            ),
                            radius = glowRadius
                        )
                    }
                    .clip(CircleShape)
                    .background(
                        brush = Brush.linearGradient(
                            if (isListening) listOf(NeonPink, NeonCyan) else listOf(NeonPink, NeonPurple)
                        )
                    )
                    .border(
                        1.5.dp,
                        if (isListening) Color.White else Color.White.copy(alpha = 0.35f),
                        CircleShape
                    )
                    .testTag("chat_microphone_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isListening) Icons.Default.Stop else Icons.Default.Mic,
                    contentDescription = if (isListening) "Stop Listening" else "Start Voice Input",
                    tint = Color.White,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}
