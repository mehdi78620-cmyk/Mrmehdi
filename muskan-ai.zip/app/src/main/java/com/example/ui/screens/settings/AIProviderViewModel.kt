package com.example.ui.screens.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.ConfigurableAIServiceImpl
import com.example.data.config.AIProviderConfig
import com.example.data.storage.SecureAIProviderStorage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class AIProviderViewModel(
    private val storage: SecureAIProviderStorage = SecureAIProviderStorage.getInstance(),
    private val aiService: ConfigurableAIServiceImpl = ConfigurableAIServiceImpl.getInstance()
) : ViewModel() {

    private val _uiState = MutableStateFlow(AIProviderUiState())
    val uiState: StateFlow<AIProviderUiState> = _uiState.asStateFlow()

    init {
        loadStoredConfiguration()
    }

    private fun loadStoredConfiguration() {
        val config = storage.getConfig()
        _uiState.update { current ->
            current.copy(
                providerName = config.providerName,
                apiKeyInput = config.apiKey,
                modelName = config.modelName,
                baseUrl = config.baseUrl ?: "",
                isConfigured = config.isConfigured,
                maskedApiKey = config.getMaskedApiKey(),
                connectionStatus = config.lastTestStatus,
                isApiKeyMasked = true,
                isEditing = !config.isConfigured // Edit mode by default if not yet configured
            )
        }
    }

    fun onProviderNameChanged(name: String) {
        _uiState.update { it.copy(providerName = name) }
    }

    fun onApiKeyChanged(key: String) {
        _uiState.update { it.copy(apiKeyInput = key, statusMessage = null) }
    }

    fun toggleApiKeyMask() {
        _uiState.update { it.copy(isApiKeyMasked = !it.isApiKeyMasked) }
    }

    fun onModelNameChanged(model: String) {
        _uiState.update { it.copy(modelName = model) }
    }

    fun onBaseUrlChanged(url: String) {
        _uiState.update { it.copy(baseUrl = url) }
    }

    fun onStartEditing() {
        _uiState.update {
            it.copy(
                isEditing = true,
                statusMessage = null
            )
        }
    }

    fun onCancelEditing() {
        val config = storage.getConfig()
        _uiState.update {
            it.copy(
                isEditing = !config.isConfigured,
                apiKeyInput = config.apiKey,
                modelName = config.modelName,
                baseUrl = config.baseUrl ?: "",
                isApiKeyMasked = true,
                statusMessage = null
            )
        }
    }

    fun onCancelEdit() = onCancelEditing()

    fun onSave() {
        val currentState = _uiState.value
        val cleanKey = currentState.apiKeyInput.trim()

        if (cleanKey.isEmpty()) {
            _uiState.update {
                it.copy(
                    statusMessage = "Please enter an API key before saving.",
                    isStatusSuccess = false
                )
            }
            return
        }

        _uiState.update { it.copy(isSaving = true) }

        val newConfig = AIProviderConfig(
            providerName = currentState.providerName.trim().ifEmpty { AIProviderConfig.PROVIDER_GOOGLE_GEMINI },
            apiKey = cleanKey,
            modelName = currentState.modelName.trim().ifEmpty { AIProviderConfig.DEFAULT_GEMINI_MODEL },
            baseUrl = currentState.baseUrl.trim().ifEmpty { null },
            lastTestStatus = if (cleanKey == storage.getConfig().apiKey) currentState.connectionStatus else AIProviderConfig.STATUS_NOT_CONFIGURED,
            lastTestTimestamp = System.currentTimeMillis()
        )

        storage.saveConfig(newConfig)

        _uiState.update {
            it.copy(
                isSaving = false,
                isEditing = false,
                isConfigured = true,
                maskedApiKey = newConfig.getMaskedApiKey(),
                isApiKeyMasked = true,
                statusMessage = "Configuration saved securely on device.",
                isStatusSuccess = true
            )
        }
    }

    fun onClearRequest() {
        _uiState.update { it.copy(showClearConfirmDialog = true) }
    }

    fun onClearDismiss() {
        _uiState.update { it.copy(showClearConfirmDialog = false) }
    }

    fun onClearConfirm() {
        storage.clearConfig()
        _uiState.update {
            it.copy(
                showClearConfirmDialog = false,
                apiKeyInput = "",
                modelName = AIProviderConfig.DEFAULT_GEMINI_MODEL,
                baseUrl = "",
                isConfigured = false,
                maskedApiKey = "",
                isEditing = true,
                isApiKeyMasked = true,
                connectionStatus = AIProviderConfig.STATUS_NOT_CONFIGURED,
                statusMessage = "Configuration cleared.",
                isStatusSuccess = null
            )
        }
    }

    fun onTestConnection() {
        val currentState = _uiState.value
        val currentKey = currentState.apiKeyInput.trim()

        if (currentKey.isEmpty()) {
            _uiState.update {
                it.copy(
                    statusMessage = "Please enter an API Key to test connection.",
                    isStatusSuccess = false
                )
            }
            return
        }

        val testConfig = AIProviderConfig(
            providerName = currentState.providerName,
            apiKey = currentKey,
            modelName = currentState.modelName.trim().ifEmpty { AIProviderConfig.DEFAULT_GEMINI_MODEL },
            baseUrl = currentState.baseUrl.trim().ifEmpty { null }
        )

        _uiState.update {
            it.copy(
                isTesting = true,
                connectionStatus = AIProviderConfig.STATUS_TESTING,
                statusMessage = "Connecting to ${testConfig.providerName}..."
            )
        }

        viewModelScope.launch {
            val result = aiService.testConnection(testConfig)
            result.fold(
                onSuccess = { successMsg ->
                    _uiState.update {
                        it.copy(
                            isTesting = false,
                            connectionStatus = AIProviderConfig.STATUS_CONNECTED,
                            statusMessage = successMsg,
                            isStatusSuccess = true
                        )
                    }
                },
                onFailure = { error ->
                    val errorMsg = error.message ?: "Connection test failed."
                    _uiState.update {
                        it.copy(
                            isTesting = false,
                            connectionStatus = AIProviderConfig.STATUS_FAILED,
                            statusMessage = errorMsg,
                            isStatusSuccess = false
                        )
                    }
                }
            )
        }
    }

    fun dismissStatus() {
        _uiState.update { it.copy(statusMessage = null, isStatusSuccess = null) }
    }
}
