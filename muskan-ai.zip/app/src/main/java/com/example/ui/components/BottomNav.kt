package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.GlassCardBorder
import com.example.ui.theme.GlassCardColor
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPinkGlow
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun HomeHistoryNav(
    currentRoute: String,
    onNavigate: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0x2E111428))
                .border(1.dp, GlassCardBorder, RoundedCornerShape(24.dp))
                .padding(4.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Home tab
                val isHomeSelected = currentRoute == "home"
                val homeBgColor by animateColorAsState(
                    targetValue = if (isHomeSelected) NeonPink.copy(alpha = 0.22f) else Color.Transparent,
                    label = "home_bg"
                )
                val homeBorderColor by animateColorAsState(
                    targetValue = if (isHomeSelected) NeonPink else Color.Transparent,
                    label = "home_border"
                )
                val homeTextColor by animateColorAsState(
                    targetValue = if (isHomeSelected) TextPrimary else TextSecondary,
                    label = "home_text"
                )

                Row(
                    modifier = Modifier
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = { onNavigate("home") }
                        )
                        .clip(RoundedCornerShape(20.dp))
                        .background(homeBgColor)
                        .border(1.dp, homeBorderColor, RoundedCornerShape(20.dp))
                        .padding(horizontal = 24.dp, vertical = 10.dp)
                        .testTag("nav_home_button"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Home,
                        contentDescription = "Home",
                        tint = if (isHomeSelected) NeonPink else TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Home",
                        color = homeTextColor,
                        fontSize = 13.sp,
                        fontWeight = if (isHomeSelected) FontWeight.Bold else FontWeight.Medium
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                // History tab
                val isHistorySelected = currentRoute == "history"
                val historyBgColor by animateColorAsState(
                    targetValue = if (isHistorySelected) NeonPink.copy(alpha = 0.22f) else Color.Transparent,
                    label = "history_bg"
                )
                val historyBorderColor by animateColorAsState(
                    targetValue = if (isHistorySelected) NeonPink else Color.Transparent,
                    label = "history_border"
                )
                val historyTextColor by animateColorAsState(
                    targetValue = if (isHistorySelected) TextPrimary else TextSecondary,
                    label = "history_text"
                )

                Row(
                    modifier = Modifier
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = { onNavigate("history") }
                        )
                        .clip(RoundedCornerShape(20.dp))
                        .background(historyBgColor)
                        .border(1.dp, historyBorderColor, RoundedCornerShape(20.dp))
                        .padding(horizontal = 24.dp, vertical = 10.dp)
                        .testTag("nav_history_button"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = "History",
                        tint = if (isHistorySelected) NeonPink else TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "History",
                        color = historyTextColor,
                        fontSize = 13.sp,
                        fontWeight = if (isHistorySelected) FontWeight.Bold else FontWeight.Medium
                    )
                }
            }
        }
    }
}

@Composable
fun BottomNav(
    currentRoute: String,
    onNavigate: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        modifier = modifier,
        containerColor = DarkBackground,
        contentColor = NeonPink
    ) {
        val items = listOf(
            Triple("home", Icons.Default.Home, "Home"),
            Triple("chat", Icons.Default.Chat, "Chat"),
            Triple("history", Icons.Default.History, "History"),
            Triple("settings", Icons.Default.Settings, "Settings")
        )

        items.forEach { (route, icon, label) ->
            NavigationBarItem(
                selected = currentRoute == route,
                onClick = { onNavigate(route) },
                icon = { Icon(imageVector = icon, contentDescription = label) },
                label = { Text(label) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = NeonPink,
                    selectedTextColor = NeonPink,
                    unselectedIconColor = TextSecondary,
                    unselectedTextColor = TextSecondary,
                    indicatorColor = Color.Transparent
                )
            )
        }
    }
}

