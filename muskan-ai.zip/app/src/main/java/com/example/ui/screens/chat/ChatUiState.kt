package com.example.ui.screens.chat

import android.net.Uri
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * UI message item representation displayed in the Chat screen.
 */
data class ChatUiMessage(
    val id: String = UUID.randomUUID().toString(),
    val text: String,
    val isUser: Boolean,
    val timestamp: String = getCurrentFormattedTime(),
    val isStreaming: Boolean = false,
    val isError: Boolean = false,
    val isSpeaking: Boolean = false,
    val attachmentUri: Uri? = null,
    val attachmentName: String? = null,
    val attachmentType: String? = null
)

private fun getCurrentFormattedTime(): String {
    val formatter = SimpleDateFormat("h:mm a", Locale.getDefault())
    return formatter.format(Date())
}

/**
 * State representing the entire Chat screen interface.
 */
data class ChatUiState(
    val conversationId: String = "",
    val conversationTitle: String = "Muskan AI",
    val memoryCount: Int = 0,
    val messages: List<ChatUiMessage> = emptyList(),
    val inputText: String = "",
    val isLoading: Boolean = false,
    val isStreaming: Boolean = false,
    val errorMessage: String? = null,
    val canRetry: Boolean = false,
    val lastFailedUserMessage: String? = null,
    // Voice conversation states
    val isListening: Boolean = false,
    val voiceRmsDb: Float = 0f,
    val voicePartialText: String = "",
    val voiceError: String? = null,
    val voiceLanguage: String = "hi-IN",
    val isTtsSpeaking: Boolean = false,
    val speakingMessageId: String? = null,
    val autoTtsEnabled: Boolean = true,
    val isVoiceModeActive: Boolean = false,
    val permissionDenied: Boolean = false,
    // Attachment states
    val attachmentUri: Uri? = null,
    val attachmentName: String? = null,
    val attachmentType: String? = null
)
