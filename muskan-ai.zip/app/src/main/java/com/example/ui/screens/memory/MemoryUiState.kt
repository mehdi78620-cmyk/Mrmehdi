package com.example.ui.screens.memory

import com.example.data.local.entity.MemoryEntity

data class MemoryUiState(
    val memories: List<MemoryEntity> = emptyList(),
    val filteredMemories: List<MemoryEntity> = emptyList(),
    val selectedCategory: String? = null,
    val isLoading: Boolean = false,
    val showAddDialog: Boolean = false,
    val newKeyInput: String = "",
    val newValueInput: String = "",
    val newCategoryInput: String = MemoryEntity.CATEGORY_PREFERENCE,
    val errorMessage: String? = null,
    val infoMessage: String? = null,
    val memoryToDelete: MemoryEntity? = null,
    val showClearAllDialog: Boolean = false
)
