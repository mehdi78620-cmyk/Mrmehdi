package com.example.ui.screens.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.ConversationEntity
import com.example.data.repository.ChatHistoryRepository
import com.example.data.repository.ChatHistoryRepositoryImpl
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class HistoryViewModel(
    private val historyRepository: ChatHistoryRepository = ChatHistoryRepositoryImpl.getInstance()
) : ViewModel() {

    private val _uiState = MutableStateFlow(HistoryUiState(isLoading = true))
    val uiState: StateFlow<HistoryUiState> = _uiState.asStateFlow()

    init {
        observeConversations()
    }

    private fun observeConversations() {
        viewModelScope.launch {
            historyRepository.getAllConversationsFlow().collect { list ->
                _uiState.update { current ->
                    val filtered = applyFilter(list, current.searchQuery)
                    current.copy(
                        conversations = list,
                        filteredConversations = filtered,
                        isLoading = false
                    )
                }
            }
        }
    }

    fun onSearchQueryChange(newQuery: String) {
        _uiState.update { current ->
            current.copy(
                searchQuery = newQuery,
                filteredConversations = applyFilter(current.conversations, newQuery)
            )
        }
    }

    private fun applyFilter(list: List<ConversationEntity>, query: String): List<ConversationEntity> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return list
        return list.filter {
            it.title.lowercase().contains(q) || it.lastSnippet.lowercase().contains(q)
        }
    }

    fun onRequestDelete(conversation: ConversationEntity) {
        _uiState.update { it.copy(conversationToDelete = conversation) }
    }

    fun onDismissDeleteDialog() {
        _uiState.update { it.copy(conversationToDelete = null) }
    }

    fun onConfirmDelete() {
        val toDelete = _uiState.value.conversationToDelete ?: return
        viewModelScope.launch {
            historyRepository.deleteConversation(toDelete.id)
            _uiState.update { it.copy(conversationToDelete = null) }
        }
    }

    fun onRequestClearAll() {
        _uiState.update { it.copy(showClearAllDialog = true) }
    }

    fun onDismissClearAllDialog() {
        _uiState.update { it.copy(showClearAllDialog = false) }
    }

    fun onConfirmClearAll() {
        viewModelScope.launch {
            historyRepository.deleteAllConversations()
            _uiState.update { it.copy(showClearAllDialog = false) }
        }
    }

    fun onStartEditTitle(conversation: ConversationEntity) {
        _uiState.update {
            it.copy(
                editingConversation = conversation,
                editedTitleInput = conversation.title
            )
        }
    }

    fun onTitleInputChange(newTitle: String) {
        _uiState.update { it.copy(editedTitleInput = newTitle) }
    }

    fun onSaveEditedTitle() {
        val conv = _uiState.value.editingConversation ?: return
        val newTitle = _uiState.value.editedTitleInput.trim()
        if (newTitle.isNotEmpty()) {
            viewModelScope.launch {
                historyRepository.updateTitle(conv.id, newTitle)
                _uiState.update { it.copy(editingConversation = null, editedTitleInput = "") }
            }
        }
    }

    fun onCancelEditTitle() {
        _uiState.update { it.copy(editingConversation = null, editedTitleInput = "") }
    }
}
