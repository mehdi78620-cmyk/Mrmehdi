package com.example.ui.screens.settings

import com.example.data.config.AIProviderConfig

data class AIProviderUiState(
    val providerName: String = AIProviderConfig.PROVIDER_GOOGLE_GEMINI,
    val apiKeyInput: String = "",
    val isApiKeyMasked: Boolean = true,
    val isEditing: Boolean = false,
    val modelName: String = AIProviderConfig.DEFAULT_GEMINI_MODEL,
    val baseUrl: String = "",
    val isConfigured: Boolean = false,
    val maskedApiKey: String = "",
    val isTesting: Boolean = false,
    val isSaving: Boolean = false,
    val connectionStatus: String = AIProviderConfig.STATUS_NOT_CONFIGURED,
    val statusMessage: String? = null,
    val isStatusSuccess: Boolean? = null,
    val showClearConfirmDialog: Boolean = false,
    val availableModels: List<String> = AIProviderConfig.POPULAR_GEMINI_MODELS
)
