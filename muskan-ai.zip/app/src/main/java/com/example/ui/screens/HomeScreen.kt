package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.components.FeatureCard
import com.example.ui.components.GlassMessageInput
import com.example.ui.components.HomeHistoryNav
import com.example.ui.components.LargeGlowingMicrophoneButton
import com.example.ui.components.MuskanAvatarSection
import com.example.ui.components.TopHeader
import com.example.ui.components.defaultMuskanFeatures
import com.example.ui.theme.DeepNavyBackground
import com.example.ui.theme.NeonPinkGlow
import com.example.ui.theme.NeonPurpleGlow

@Composable
fun HomeScreen(
    onNavigateToChat: () -> Unit,
    modifier: Modifier = Modifier,
    onNavigateToHistory: () -> Unit = {},
    onNavigateToSettings: () -> Unit = {},
    onNavigateToWebSearch: () -> Unit = {},
    onNavigateToCoding: () -> Unit = {},
    onNavigateToCreateImage: () -> Unit = {},
    onNavigateToVoice: () -> Unit = {},
    onNavigateToCamera: () -> Unit = {},
    onNavigateToFiles: () -> Unit = {},
    onNavigateToMore: () -> Unit = {},
    onMenuClick: () -> Unit = onNavigateToMore
) {
    var messageText by remember { mutableStateOf("") }
    val scrollState = rememberScrollState()

    val handleFeatureClick: (String) -> Unit = { title ->
        when (title) {
            "Chat" -> onNavigateToChat()
            "Web Search" -> onNavigateToWebSearch()
            "Create Image" -> onNavigateToCreateImage()
            "Coding" -> onNavigateToCoding()
            "Voice" -> onNavigateToVoice()
            "Camera" -> onNavigateToCamera()
            "Files" -> onNavigateToFiles()
            "More" -> onNavigateToMore()
            else -> onNavigateToChat()
        }
    }

    // Futuristic deep black/navy background with subtle pink and purple radial glows
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DeepNavyBackground)
            .drawBehind {
                // Top-center subtle purple aura
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            NeonPurpleGlow.copy(alpha = 0.28f),
                            Color.Transparent
                        ),
                        center = Offset(size.width * 0.5f, size.height * 0.18f),
                        radius = size.width * 0.65f
                    )
                )

                // Center glowing pink aura behind avatar and greetings
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            NeonPinkGlow.copy(alpha = 0.22f),
                            Color.Transparent
                        ),
                        center = Offset(size.width * 0.5f, size.height * 0.38f),
                        radius = size.width * 0.75f
                    )
                )

                // Bottom ambient glow near microphone
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            NeonPinkGlow.copy(alpha = 0.18f),
                            Color.Transparent
                        ),
                        center = Offset(size.width * 0.8f, size.height * 0.88f),
                        radius = size.width * 0.55f
                    )
                )
            }
            .testTag("muskan_home_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // TOP HEADER
            TopHeader(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp, bottom = 12.dp),
                title = "Muskan AI",
                subtitle = "Always With You",
                onMenuClick = onMenuClick,
                onSettingsClick = onNavigateToSettings
            )

            // SCROLLABLE CENTER CONTENT (Avatar + Greetings + Feature Cards)
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(scrollState)
                    .padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // CENTER: Circular profile, glowing ring, outer glow, heart, greetings
                MuskanAvatarSection(
                    modifier = Modifier.padding(bottom = 20.dp)
                )

                // FEATURE CARDS: 8 cards organized in responsive 2-column rows
                val features = defaultMuskanFeatures
                for (i in features.indices step 2) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 5.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        val firstFeature = features[i]
                        FeatureCard(
                            title = firstFeature.title,
                            subtitle = firstFeature.subtitle,
                            icon = firstFeature.icon,
                            neonAccent = firstFeature.neonAccent,
                            glowColor = firstFeature.glowColor,
                            modifier = Modifier.weight(1f),
                            onClick = {
                                handleFeatureClick(firstFeature.title)
                            }
                        )

                        if (i + 1 < features.size) {
                            val secondFeature = features[i + 1]
                            FeatureCard(
                                title = secondFeature.title,
                                subtitle = secondFeature.subtitle,
                                icon = secondFeature.icon,
                                neonAccent = secondFeature.neonAccent,
                                glowColor = secondFeature.glowColor,
                                modifier = Modifier.weight(1f),
                                onClick = {
                                    handleFeatureClick(secondFeature.title)
                                }
                            )
                        } else {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }

            // BOTTOM SECTION: Glass message input, glowing mic, and Home & History navigation
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp, bottom = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Message input & glowing microphone row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    GlassMessageInput(
                        value = messageText,
                        onValueChange = { messageText = it },
                        onSend = {
                            messageText = ""
                            onNavigateToChat()
                        },
                        placeholder = "Type a message...",
                        modifier = Modifier.weight(1f)
                    )

                    Spacer(modifier = Modifier.width(10.dp))

                    LargeGlowingMicrophoneButton(
                        onClick = onNavigateToVoice
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Home and History navigation
                HomeHistoryNav(
                    currentRoute = "home",
                    onNavigate = { route ->
                        if (route == "history") {
                            onNavigateToHistory()
                        }
                    }
                )
            }
        }
    }
}

