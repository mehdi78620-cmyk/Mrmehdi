package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DeepNavyBackground = Color(0xFF080914)
val DeepNavySurface = Color(0xFF0F1123)
val DarkBackground = DeepNavyBackground

val NeonPink = Color(0xFFFF007F)
val NeonPurple = Color(0xFFB026FF)
val NeonCyan = Color(0xFF00E5FF)
val NeonRose = Color(0xFFFF3399)

val GlassCardColor = Color(0x1AFFFFFF) // Frosted glass overlay
val GlassCardBorder = Color(0x2EFFFFFF) // Subtle glass edge

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFA5A8C0)
val TextMuted = Color(0xFF6E7394)

val NeonPinkGlow = Color(0x4DFF007F)
val NeonPurpleGlow = Color(0x4DB026FF)
val NeonCyanGlow = Color(0x4D00E5FF)

