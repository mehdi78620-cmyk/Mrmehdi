package com.example.data.api

import com.example.data.config.AIConfig
import com.example.data.model.ChatMessageItem
import com.example.data.model.MessageRole
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

/**
 * Production-ready backend AI Service implementation.
 *
 * Communicates with a secure backend server that manages the AI provider's private credentials
 * (Gemini, Claude, GPT, etc.), protecting keys from extraction via decompiled APKs.
 *
 * Supports both streaming (Server-Sent Events / SSE) and standard JSON responses.
 */
class BackendAIServiceImpl(
    private val client: OkHttpClient = defaultOkHttpClient
) : AIService {

    companion object {
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

        val defaultOkHttpClient: OkHttpClient by lazy {
            OkHttpClient.Builder()
                .connectTimeout(AIConfig.CONNECT_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                .readTimeout(AIConfig.READ_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                .writeTimeout(AIConfig.WRITE_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .build()
        }
    }

    override fun sendMessageStream(
        messages: List<ChatMessageItem>,
        systemInstruction: String
    ): Flow<AIStreamEvent> = flow {
        val requestJson = buildRequestBody(messages, systemInstruction, stream = true)
        val chatUrl = AIConfig.getChatUrl()

        val httpRequest = Request.Builder()
            .url(chatUrl)
            .post(requestJson.toString().toRequestBody(JSON_MEDIA_TYPE))
            .addHeader("Accept", "text/event-stream, application/json, text/plain")
            .addHeader("Content-Type", "application/json")
            .build()

        val fullTextBuilder = StringBuilder()

        try {
            val response = client.newCall(httpRequest).execute()

            if (!response.isSuccessful) {
                val errorBody = response.body?.string().orEmpty()
                val friendlyMessage = mapHttpError(response.code, errorBody, chatUrl)
                emit(AIStreamEvent.Error(
                    throwable = IllegalStateException("HTTP ${response.code}: $friendlyMessage"),
                    userFriendlyMessage = friendlyMessage
                ))
                return@flow
            }

            val responseBody = response.body
            if (responseBody == null) {
                emit(AIStreamEvent.Error(
                    throwable = IllegalStateException("Empty response from backend"),
                    userFriendlyMessage = "Received an empty response from the AI server. Please try again."
                ))
                return@flow
            }

            val contentType = response.header("Content-Type").orEmpty().lowercase()
            val isSseStream = contentType.contains("text/event-stream")

            val reader = BufferedReader(InputStreamReader(responseBody.byteStream(), Charsets.UTF_8))

            reader.use { bufferedReader ->
                var line: String?
                var streamActive = true

                while (bufferedReader.readLine().also { line = it } != null && streamActive) {
                    val rawLine = line ?: continue
                    val trimmedLine = rawLine.trim()

                    if (trimmedLine.isEmpty() || trimmedLine.startsWith(":")) {
                        // Ping or comment line
                        continue
                    }

                    if (trimmedLine.startsWith("data:")) {
                        val dataContent = trimmedLine.removePrefix("data:").trim()
                        if (dataContent == "[DONE]") {
                            streamActive = false
                            break
                        }

                        val chunkText = parseChunkFromData(dataContent)
                        if (chunkText.isNotEmpty()) {
                            fullTextBuilder.append(chunkText)
                            emit(AIStreamEvent.Chunk(chunkText))
                        }
                    } else {
                        // Might be plain JSON or raw chunked text
                        val chunkText = parseChunkFromData(trimmedLine)
                        if (chunkText.isNotEmpty()) {
                            fullTextBuilder.append(chunkText)
                            emit(AIStreamEvent.Chunk(chunkText))
                        }
                    }
                }
            }

            val finalOutput = fullTextBuilder.toString().trim()
            if (finalOutput.isNotEmpty()) {
                emit(AIStreamEvent.Complete(finalOutput))
            } else {
                emit(AIStreamEvent.Error(
                    throwable = IllegalStateException("No content generated"),
                    userFriendlyMessage = "Muskan AI did not return any text. Please try again."
                ))
            }

        } catch (e: UnknownHostException) {
            emit(AIStreamEvent.Error(
                throwable = e,
                userFriendlyMessage = "Unable to connect to AI server (${AIConfig.getBaseUrl()}). Please check your internet connection or verify the backend server is online."
            ))
        } catch (e: ConnectException) {
            emit(AIStreamEvent.Error(
                throwable = e,
                userFriendlyMessage = "Connection refused by backend at ${AIConfig.getChatUrl()}. Please ensure the backend service is deployed and accessible."
            ))
        } catch (e: SocketTimeoutException) {
            emit(AIStreamEvent.Error(
                throwable = e,
                userFriendlyMessage = "Request timed out waiting for Muskan AI. Please try again."
            ))
        } catch (e: Exception) {
            emit(AIStreamEvent.Error(
                throwable = e,
                userFriendlyMessage = e.localizedMessage ?: "An unexpected error occurred while communicating with the AI service."
            ))
        }
    }.flowOn(Dispatchers.IO)

    override suspend fun sendMessage(
        messages: List<ChatMessageItem>,
        systemInstruction: String
    ): Result<String> {
        val resultBuilder = StringBuilder()
        var errorOccurred: Throwable? = null
        var errorMessage: String? = null

        sendMessageStream(messages, systemInstruction).collect { event ->
            when (event) {
                is AIStreamEvent.Chunk -> resultBuilder.append(event.text)
                is AIStreamEvent.Complete -> { /* completed */ }
                is AIStreamEvent.Error -> {
                    errorOccurred = event.throwable
                    errorMessage = event.userFriendlyMessage
                }
            }
        }

        return if (errorOccurred != null) {
            Result.failure(errorOccurred ?: Exception(errorMessage))
        } else {
            Result.success(resultBuilder.toString())
        }
    }

    /**
     * Builds standard JSON request body containing messages, system instruction,
     * and model configuration.
     */
    private fun buildRequestBody(
        messages: List<ChatMessageItem>,
        systemInstruction: String,
        stream: Boolean
    ): JSONObject {
        val json = JSONObject()
        json.put("model", AIConfig.DEFAULT_MODEL_ID)
        json.put("stream", stream)
        json.put("system_prompt", systemInstruction)

        val messagesArray = JSONArray()

        // 1. Add System Message
        val systemMsg = JSONObject()
        systemMsg.put("role", "system")
        systemMsg.put("content", systemInstruction)
        messagesArray.put(systemMsg)

        // 2. Add Recent Conversation Turns
        val contextSubset = if (messages.size > AIConfig.MAX_CONTEXT_TURNS) {
            messages.takeLast(AIConfig.MAX_CONTEXT_TURNS)
        } else {
            messages
        }

        for (item in contextSubset) {
            val msgObj = JSONObject()
            msgObj.put("role", item.role.toApiRole())
            msgObj.put("content", item.content)
            messagesArray.put(msgObj)
        }

        json.put("messages", messagesArray)
        return json
    }

    /**
     * Parses chunk text from SSE data or standard JSON payload.
     * Supports various backend response formats (OpenAI-compatible, Gemini proxy, or custom).
     */
    private fun parseChunkFromData(data: String): String {
        if (data.isEmpty()) return ""

        try {
            val json = JSONObject(data)

            // Format 1: Direct "text", "content", or "reply" fields
            if (json.has("text")) return json.optString("text")
            if (json.has("content")) return json.optString("content")
            if (json.has("reply")) return json.optString("reply")

            // Format 2: OpenAI-compatible delta choices
            val choices = json.optJSONArray("choices")
            if (choices != null && choices.length() > 0) {
                val firstChoice = choices.optJSONObject(0)
                if (firstChoice != null) {
                    val delta = firstChoice.optJSONObject("delta")
                    if (delta != null && delta.has("content")) {
                        return delta.optString("content")
                    }
                    val message = firstChoice.optJSONObject("message")
                    if (message != null && message.has("content")) {
                        return message.optString("content")
                    }
                    if (firstChoice.has("text")) {
                        return firstChoice.optString("text")
                    }
                }
            }

            // Format 3: Gemini candidates format (if backend proxies raw Gemini response)
            val candidates = json.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                val firstCand = candidates.optJSONObject(0)
                val contentObj = firstCand?.optJSONObject("content")
                val parts = contentObj?.optJSONArray("parts")
                if (parts != null && parts.length() > 0) {
                    val firstPart = parts.optJSONObject(0)
                    if (firstPart != null && firstPart.has("text")) {
                        return firstPart.optString("text")
                    }
                }
            }
        } catch (_: Exception) {
            // If data is just raw text string
            if (!data.startsWith("{") && !data.startsWith("[")) {
                return data
            }
        }

        return ""
    }

    private fun mapHttpError(code: Int, body: String, url: String): String {
        return when (code) {
            401, 403 -> "Authentication failed at $url. Please check your backend authorization credentials."
            404 -> "Endpoint not found ($url). Please ensure the backend chat route is correctly configured."
            429 -> "Rate limit exceeded. Please wait a moment before sending another message."
            500, 502, 503 -> "Backend AI server error ($code). The server may be restarting or overloaded."
            else -> "Server error ($code). ${body.take(100)}"
        }
    }
}
