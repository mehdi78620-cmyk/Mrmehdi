package com.example.data.repository

import android.content.Context
import com.example.data.config.AppSettings
import com.example.data.storage.SettingsStorage
import kotlinx.coroutines.flow.StateFlow

/**
 * Repository layer for managing app settings and user preferences.
 */
class SettingsRepository private constructor(context: Context) {

    private val storage: SettingsStorage = SettingsStorage.getInstance(context)

    val settingsFlow: StateFlow<AppSettings> = storage.settingsFlow

    fun getSettings(): AppSettings {
        return storage.getSettings()
    }

    fun updateSettings(settings: AppSettings) {
        storage.saveSettings(settings)
    }

    fun updateResponseSettings(style: String, temperature: Float, language: String) {
        val current = storage.getSettings()
        storage.saveSettings(
            current.copy(
                responseStyle = style,
                temperature = temperature,
                responseLanguage = language
            )
        )
    }

    fun updateVoiceSettings(
        voiceEnabled: Boolean,
        speechLang: String,
        ttsEnabled: Boolean,
        speed: Float,
        pitch: Float
    ) {
        val current = storage.getSettings()
        storage.saveSettings(
            current.copy(
                voiceEnabled = voiceEnabled,
                speechRecognitionLanguage = speechLang,
                ttsEnabled = ttsEnabled,
                voiceSpeed = speed,
                voicePitch = pitch
            )
        )
    }

    fun updatePersonalization(
        assistantName: String,
        userName: String,
        instructions: String,
        style: String
    ) {
        val current = storage.getSettings()
        storage.saveSettings(
            current.copy(
                assistantName = assistantName,
                userName = userName,
                personalInstructions = instructions,
                personalityStyle = style
            )
        )
    }

    fun updateMemorySettings(enabled: Boolean) {
        val current = storage.getSettings()
        storage.saveSettings(current.copy(memoryEnabled = enabled))
    }

    fun updateAppearance(darkTheme: Boolean, neonIntensity: Float, animations: Boolean, reduceAnim: Boolean) {
        val current = storage.getSettings()
        storage.saveSettings(
            current.copy(
                darkTheme = darkTheme,
                neonIntensity = neonIntensity,
                animationsEnabled = animations,
                reduceAnimations = reduceAnim
            )
        )
    }

    companion object {
        @Volatile
        private var instance: SettingsRepository? = null

        fun getInstance(context: Context): SettingsRepository {
            return instance ?: synchronized(this) {
                instance ?: SettingsRepository(context.applicationContext).also { instance = it }
            }
        }
    }
}
