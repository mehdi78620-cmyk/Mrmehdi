package com.example.data.model

import java.util.UUID

enum class MessageRole {
    SYSTEM,
    USER,
    ASSISTANT;

    fun toApiRole(): String = when (this) {
        SYSTEM -> "system"
        USER -> "user"
        ASSISTANT -> "assistant"
    }

    companion object {
        fun fromString(role: String): MessageRole = when (role.lowercase()) {
            "system" -> SYSTEM
            "user" -> USER
            "assistant", "model" -> ASSISTANT
            else -> USER
        }
    }
}

/**
 * Domain representation of a chat turn stored in the conversation context.
 */
data class ChatMessageItem(
    val id: String = UUID.randomUUID().toString(),
    val role: MessageRole,
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)
