package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.local.dao.ChatMessageDao
import com.example.data.local.dao.ConversationDao
import com.example.data.local.dao.MemoryDao
import com.example.data.local.entity.ChatMessageEntity
import com.example.data.local.entity.ConversationEntity
import com.example.data.local.entity.MemoryEntity

@Database(
    entities = [
        ConversationEntity::class,
        ChatMessageEntity::class,
        MemoryEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun conversationDao(): ConversationDao
    abstract fun chatMessageDao(): ChatMessageDao
    abstract fun memoryDao(): MemoryDao

    companion object {
        private const val DB_NAME = "muskan_ai_database.db"

        @Volatile
        private var instance: AppDatabase? = null

        fun initialize(context: Context): AppDatabase {
            return instance ?: synchronized(this) {
                instance ?: buildDatabase(context.applicationContext).also { instance = it }
            }
        }

        fun getInstance(context: Context? = null): AppDatabase {
            instance?.let { return it }
            return synchronized(this) {
                instance ?: buildDatabase(context).also { instance = it }
            }
        }

        private fun buildDatabase(context: Context?): AppDatabase {
            val resolvedContext = context?.applicationContext ?: try {
                val app = Class.forName("android.app.ActivityThread")
                    .getMethod("currentApplication")
                    .invoke(null) as? Context
                app ?: throw IllegalStateException("Context not available")
            } catch (_: Exception) {
                try {
                    val appProvider = Class.forName("androidx.test.core.app.ApplicationProvider")
                    appProvider.getMethod("getApplicationContext").invoke(null) as Context
                } catch (_: Exception) {
                    throw IllegalStateException("Cannot resolve Context for AppDatabase")
                }
            }

            return Room.databaseBuilder(
                resolvedContext,
                AppDatabase::class.java,
                DB_NAME
            ).fallbackToDestructiveMigration()
            .build()
        }
    }
}
