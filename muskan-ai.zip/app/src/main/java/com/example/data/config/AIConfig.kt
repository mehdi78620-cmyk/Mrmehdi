package com.example.data.config

/**
 * Isolated AI Provider and Model Configuration.
 *
 * Keeps endpoint URLs, model identifiers, system prompts, and network parameters
 * separated from the business logic and UI. This allows switching backend providers
 * (e.g., custom proxy server, cloud function, or another LLM gateway) without
 * altering UI or conversation layers.
 */
object AIConfig {

    /**
     * Default base URL of the secure backend proxy server.
     * In a production deployment, this server handles authentication, rate-limiting,
     * and securely holds the LLM provider's private API keys (Gemini, Claude, GPT, etc.).
     *
     * Developers can update this URL to their deployed cloud function or local server
     * (e.g., "http://10.0.2.2:8080/" for local emulator testing).
     */
    const val DEFAULT_BACKEND_BASE_URL: String = "https://api.muskanai.com/"

    /**
     * The chat completion route on the backend server.
     */
    const val CHAT_ENDPOINT: String = "api/chat"

    /**
     * Model identifier sent to the backend.
     */
    const val DEFAULT_MODEL_ID: String = "muskan-ai-chat-v1"

    /**
     * Network timeouts in seconds.
     */
    const val CONNECT_TIMEOUT_SECONDS: Long = 20L
    const val READ_TIMEOUT_SECONDS: Long = 60L
    const val WRITE_TIMEOUT_SECONDS: Long = 30L

    /**
     * Max conversation history turns sent in context window.
     */
    const val MAX_CONTEXT_TURNS: Int = 20

    /**
     * Dynamic base URL override (for runtime configuration or staging environments).
     */
    @Volatile
    private var customBaseUrl: String? = null

    fun setCustomBaseUrl(url: String?) {
        customBaseUrl = url?.trim()?.let {
            if (!it.endsWith("/")) "$it/" else it
        }
    }

    fun getBaseUrl(): String {
        return customBaseUrl ?: DEFAULT_BACKEND_BASE_URL
    }

    /**
     * Full URL for chat endpoint.
     */
    fun getChatUrl(): String {
        val base = getBaseUrl()
        return if (base.endsWith("/")) "$base$CHAT_ENDPOINT" else "$base/$CHAT_ENDPOINT"
    }

    /**
     * Muskan AI Persona and System Prompt.
     * Configured for seamless multilingual conversation in Hindi, Hinglish, and English.
     */
    const val MUSKAN_SYSTEM_PROMPT: String = """
You are Muskan AI (मुस्कान), a warm, caring, highly intelligent, and friendly personal AI assistant and companion.

Core Guidelines:
1. Language Fluency:
   - Understand and respond fluently in Hindi (हिंदी script), Hinglish (Romanized Hindi, e.g., "Aap kaise hain? Main aapki madad karne ke liye tayyar hoon ❤️"), and English.
   - Naturally match the language and tone of the user's message. If the user talks in Hinglish, reply in warm Hinglish; if in Hindi, reply in Hindi; if in English, reply in English.
2. Personality & Warmth:
   - Be affectionate, attentive, supportive, respectful, and polite.
   - You may use warm terms like "Jaan", "Dost", or respectful "Aap" naturally and affectionately.
   - Show genuine care for the user's well-being and daily tasks.
3. Capabilities:
   - Provide accurate, thoughtful, and insightful assistance across daily planning, brainstorming, question answering, creative writing, and coding help.
   - When answering complex questions, keep explanations clear, concise, and structured.
4. Memory & Context:
   - Remember details discussed in the current conversation and reference them naturally.
"""
}
