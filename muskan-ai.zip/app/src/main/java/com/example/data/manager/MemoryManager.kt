package com.example.data.manager

import com.example.data.local.entity.MemoryEntity
import com.example.data.repository.MemoryRepository
import com.example.data.repository.MemoryRepositoryImpl
import kotlinx.coroutines.flow.Flow
import java.util.regex.Pattern

/**
 * Manages user-approved preferences and useful conversation context.
 * Strictly prevents saving sensitive information (passwords, payment cards, CVVs, credentials).
 * Formats memory context for AI prompts so Muskan AI can personalize responses.
 */
class MemoryManager(
    private val memoryRepository: MemoryRepository = MemoryRepositoryImpl.getInstance()
) {

    /**
     * Flow of all currently active approved memories.
     */
    fun getAllMemoriesFlow(): Flow<List<MemoryEntity>> {
        return memoryRepository.getAllApprovedMemoriesFlow()
    }

    /**
     * Retrieves all memories as a list.
     */
    suspend fun getAllMemories(): List<MemoryEntity> {
        return memoryRepository.getAllApprovedMemories()
    }

    /**
     * Flow for the count of remembered items.
     */
    fun getMemoryCountFlow(): Flow<Int> {
        return memoryRepository.countApprovedMemoriesFlow()
    }

    /**
     * Saves a user-approved preference or context item.
     * Throws [IllegalArgumentException] if sensitive information is detected.
     */
    suspend fun savePreference(
        key: String,
        value: String,
        category: String = MemoryEntity.CATEGORY_PREFERENCE,
        source: String = "User"
    ): Result<MemoryEntity> {
        val trimmedKey = key.trim()
        val trimmedVal = value.trim()

        if (trimmedKey.isEmpty() || trimmedVal.isEmpty()) {
            return Result.failure(IllegalArgumentException("Key and value cannot be empty."))
        }

        if (isSensitiveData(trimmedKey) || isSensitiveData(trimmedVal)) {
            return Result.failure(
                SecurityException("For your privacy and security, sensitive personal information (such as passwords, credit cards, bank accounts, or credentials) cannot be stored.")
            )
        }

        val saved = memoryRepository.saveMemory(
            key = trimmedKey,
            value = trimmedVal,
            category = category,
            source = source
        )
        return Result.success(saved)
    }

    /**
     * Deletes a specific memory item by ID.
     */
    suspend fun deleteMemory(id: String) {
        memoryRepository.deleteMemory(id)
    }

    /**
     * Clears all saved memories.
     */
    suspend fun clearAllMemories() {
        memoryRepository.clearAllMemories()
    }

    /**
     * Generates a concise, structured prompt section to inject into the AI system instruction.
     */
    suspend fun getMemoryContextForAI(): String {
        val memories = memoryRepository.getAllApprovedMemories()
        if (memories.isEmpty()) return ""

        val sb = StringBuilder()
        sb.append("\n\n[USER CONTEXT & APPROVED PREFERENCES]\n")
        sb.append("The user has explicitly saved and approved the following preferences. Naturally incorporate these into your responses where helpful, without reciting this list verbatim unless asked:\n")
        memories.forEach { memory ->
            sb.append("• ${memory.key}: ${memory.value} (${memory.category})\n")
        }
        return sb.toString()
    }

    /**
     * Detects if text contains sensitive data like passwords, credit cards, CVVs, or OTPs.
     */
    fun isSensitiveData(text: String): Boolean {
        val lower = text.lowercase()

        // 1. Keyword check for secrets
        val sensitiveKeywords = listOf(
            "password", "passwd", "pin code", "atm pin", "cvv", "cvc",
            "credit card", "debit card", "secret key", "private key",
            "seed phrase", "otp", "aadhaar", "social security", "ssn"
        )
        if (sensitiveKeywords.any { lower.contains(it) }) {
            return true
        }

        // 2. Credit card number pattern (13 to 19 digits)
        val cardRegex = Pattern.compile("\\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|6(?:011|5[0-9]{2})[0-9]{12}|(?:2131|1800|35\\d{3})\\d{11})\\b")
        if (cardRegex.matcher(text.replace(" ", "").replace("-", "")).find()) {
            return true
        }

        // 3. OTP or PIN pattern (isolated 4-8 digit codes following keyword)
        val otpPattern = Pattern.compile("(?i)\\b(otp|pin|cvv)\\s*[:=-]?\\s*\\d{3,8}\\b")
        if (otpPattern.matcher(text).find()) {
            return true
        }

        return false
    }

    /**
     * Analyzes user prompt to see if user is expressing a preference they might want remembered.
     */
    fun detectPreferenceCandidate(userText: String): Pair<String, String>? {
        val trimmed = userText.trim()
        if (isSensitiveData(trimmed)) return null

        val lower = trimmed.lowercase()

        // "Remember that my name is Rahul" / "Mera naam Rahul hai"
        val nameRegex1 = Regex("(?i)(?:remember that )?my name is\\s+([a-zA-Z]+)", RegexOption.IGNORE_CASE)
        val nameMatch1 = nameRegex1.find(trimmed)
        if (nameMatch1 != null) {
            val name = nameMatch1.groupValues[1].replaceFirstChar { it.uppercase() }
            return "User's Name" to name
        }

        val nameRegex2 = Regex("(?i)mera naam\\s+([a-zA-Z]+)\\s+hai", RegexOption.IGNORE_CASE)
        val nameMatch2 = nameRegex2.find(trimmed)
        if (nameMatch2 != null) {
            val name = nameMatch2.groupValues[1].replaceFirstChar { it.uppercase() }
            return "User's Name" to name
        }

        // "Remember that I prefer Hinglish" / "I prefer Hinglish"
        if (lower.contains("prefer hinglish") || lower.contains("reply in hinglish")) {
            return "Language Preference" to "Hinglish"
        }
        if (lower.contains("prefer hindi") || lower.contains("reply in hindi")) {
            return "Language Preference" to "Hindi"
        }
        if (lower.contains("prefer english") || lower.contains("reply in english")) {
            return "Language Preference" to "English"
        }

        // Explicit "Remember that ..."
        if (lower.startsWith("remember that ") || lower.startsWith("remember: ")) {
            val fact = trimmed.substringAfter("remember that ").substringAfter("remember: ").trim()
            if (fact.length in 3..120 && !isSensitiveData(fact)) {
                return "User Note" to fact
            }
        }

        return null
    }

    companion object {
        @Volatile
        private var instance: MemoryManager? = null

        fun getInstance(): MemoryManager {
            return instance ?: synchronized(this) {
                instance ?: MemoryManager().also { instance = it }
            }
        }
    }
}
