package com.example.data.api

import android.util.Log
import com.example.data.config.AIConfig
import com.example.data.config.AIProviderConfig
import com.example.data.model.ChatMessageItem
import com.example.data.model.MessageRole
import com.example.data.storage.SecureAIProviderStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.nio.charset.StandardCharsets
import java.util.concurrent.TimeUnit

/**
 * Production implementation of [AIService] that connects directly to the
 * user's manually configured AI Provider (initially Google Gemini).
 *
 * Security & Design:
 * - Never contains hardcoded API keys in source code.
 * - Reads API key and provider configuration dynamically from [SecureAIProviderStorage].
 * - Supports streaming (SSE) and full non-streaming generation.
 * - Multi-turn conversation format compliant with Google Gemini specifications:
 *   roles "user" and "model", system prompt in "system_instruction".
 */
class ConfigurableAIServiceImpl(
    private val storage: SecureAIProviderStorage = SecureAIProviderStorage.getInstance()
) : AIService {

    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(AIConfig.CONNECT_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .readTimeout(AIConfig.READ_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .writeTimeout(AIConfig.WRITE_TIMEOUT_SECONDS, TimeUnit.SECONDS)
        .build()

    override fun sendMessageStream(
        messages: List<ChatMessageItem>,
        systemInstruction: String
    ): Flow<AIStreamEvent> = flow {
        val config = storage.getConfig()

        // 1. Verify that user has configured their API key
        if (!config.isConfigured) {
            emit(
                AIStreamEvent.Error(
                    throwable = IllegalStateException("API Key not configured"),
                    userFriendlyMessage = "AI Provider is not configured yet. Please open Settings → AI Provider to enter your Google Gemini API key."
                )
            )
            return@flow
        }

        when (config.providerName) {
            AIProviderConfig.PROVIDER_GOOGLE_GEMINI -> {
                executeGeminiStream(config, messages, systemInstruction, this)
            }
            else -> {
                // Extensible fallback
                executeGeminiStream(config, messages, systemInstruction, this)
            }
        }
    }.flowOn(Dispatchers.IO)

    override suspend fun sendMessage(
        messages: List<ChatMessageItem>,
        systemInstruction: String
    ): Result<String> = withContext(Dispatchers.IO) {
        val config = storage.getConfig()

        if (!config.isConfigured) {
            return@withContext Result.failure(
                IllegalStateException("AI Provider is not configured yet. Please open Settings → AI Provider to enter your Google Gemini API key.")
            )
        }

        try {
            val baseUrl = config.getEffectiveBaseUrl()
            val url = "${baseUrl}v1beta/models/${config.modelName}:generateContent?key=${config.apiKey}"
            val requestJson = buildGeminiRequestBody(messages, systemInstruction)
            val requestBody = requestJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType())

            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .addHeader("Content-Type", "application/json")
                .build()

            httpClient.newCall(request).execute().use { response ->
                val bodyString = response.body?.string() ?: ""
                if (!response.isSuccessful) {
                    val friendlyError = parseHttpError(response.code, bodyString, config.modelName)
                    return@withContext Result.failure(Exception(friendlyError))
                }

                val fullText = parseGeminiNonStreamingResponse(bodyString)
                if (fullText.isNotBlank()) {
                    Result.success(fullText)
                } else {
                    Result.failure(Exception("Gemini returned an empty response."))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Tests connectivity and API key validity against the configured provider.
     */
    suspend fun testConnection(config: AIProviderConfig): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = config.apiKey.trim()
        if (apiKey.isEmpty()) {
            return@withContext Result.failure(IllegalArgumentException("Please enter an API Key to test connection."))
        }

        val startTime = System.currentTimeMillis()
        try {
            val baseUrl = config.getEffectiveBaseUrl()
            val url = "${baseUrl}v1beta/models/${config.modelName}:generateContent?key=$apiKey"

            // Lightweight ping prompt
            val pingJson = JSONObject().apply {
                val contents = JSONArray().apply {
                    put(JSONObject().apply {
                        put("role", "user")
                        put("parts", JSONArray().apply {
                            put(JSONObject().put("text", "Hello"))
                        })
                    })
                }
                put("contents", contents)
                put("generationConfig", JSONObject().put("maxOutputTokens", 10))
            }

            val requestBody = pingJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .addHeader("Content-Type", "application/json")
                .build()

            httpClient.newCall(request).execute().use { response ->
                val latency = System.currentTimeMillis() - startTime
                val bodyString = response.body?.string() ?: ""

                if (response.isSuccessful) {
                    val statusText = "Connected to ${config.providerName} (${config.modelName}) • ${latency}ms"
                    storage.updateTestStatus(AIProviderConfig.STATUS_CONNECTED)
                    Result.success(statusText)
                } else {
                    val errorDetail = parseHttpError(response.code, bodyString, config.modelName)
                    storage.updateTestStatus("${AIProviderConfig.STATUS_FAILED}: ${response.code}")
                    Result.failure(Exception(errorDetail))
                }
            }
        } catch (e: Exception) {
            val msg = e.localizedMessage ?: "Network connection failed"
            storage.updateTestStatus("${AIProviderConfig.STATUS_FAILED}: $msg")
            Result.failure(e)
        }
    }

    private suspend fun executeGeminiStream(
        config: AIProviderConfig,
        messages: List<ChatMessageItem>,
        systemInstruction: String,
        collector: kotlinx.coroutines.flow.FlowCollector<AIStreamEvent>
    ) {
        try {
            val baseUrl = config.getEffectiveBaseUrl()
            // SSE endpoint for Google Gemini
            val url = "${baseUrl}v1beta/models/${config.modelName}:streamGenerateContent?alt=sse&key=${config.apiKey}"
            val requestJson = buildGeminiRequestBody(messages, systemInstruction)
            val requestBody = requestJson.toString().toRequestBody("application/json; charset=utf-8".toMediaType())

            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .addHeader("Content-Type", "application/json")
                .addHeader("Accept", "text/event-stream, application/json")
                .build()

            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    val errorBody = response.body?.string() ?: ""
                    val friendlyError = parseHttpError(response.code, errorBody, config.modelName)
                    collector.emit(
                        AIStreamEvent.Error(
                            throwable = Exception("HTTP ${response.code}"),
                            userFriendlyMessage = friendlyError
                        )
                    )
                    return
                }

                val responseBody = response.body ?: run {
                    collector.emit(AIStreamEvent.Error(Exception("Empty body"), "No response received from AI Provider."))
                    return
                }

                val reader = BufferedReader(InputStreamReader(responseBody.byteStream(), StandardCharsets.UTF_8))
                val fullResponseBuilder = StringBuilder()
                var line: String?

                while (reader.readLine().also { line = it } != null) {
                    val currentLine = line?.trim() ?: continue
                    if (currentLine.isEmpty() || currentLine.startsWith(":")) {
                        continue // SSE keep-alive or comment
                    }

                    if (currentLine.startsWith("data:")) {
                        val dataContent = currentLine.removePrefix("data:").trim()
                        if (dataContent == "[DONE]") {
                            break
                        }

                        val chunkText = extractGeminiChunkText(dataContent)
                        if (!chunkText.isNullOrEmpty()) {
                            fullResponseBuilder.append(chunkText)
                            collector.emit(AIStreamEvent.Chunk(chunkText))
                        }
                    }
                }

                val completeText = fullResponseBuilder.toString().trim()
                if (completeText.isNotEmpty()) {
                    collector.emit(AIStreamEvent.Complete(completeText))
                } else {
                    collector.emit(AIStreamEvent.Error(Exception("Empty reply"), "Received empty response from AI Provider."))
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Gemini stream error", e)
            val userMsg = when (e) {
                is java.net.UnknownHostException -> "No internet connection. Please check your network."
                is java.net.SocketTimeoutException -> "Request timed out while waiting for AI response."
                else -> "Connection error: ${e.localizedMessage ?: "Unable to connect to AI provider"}"
            }
            collector.emit(AIStreamEvent.Error(e, userMsg))
        }
    }

    private fun buildGeminiRequestBody(
        messages: List<ChatMessageItem>,
        systemInstruction: String
    ): JSONObject {
        val root = JSONObject()

        // 1. Multi-turn contents
        val contentsArray = JSONArray()

        // Gemini rule: First turn in contents MUST be "user"
        val turns = messages.dropWhile { it.role != MessageRole.USER }

        for (item in turns) {
            val role = when (item.role) {
                MessageRole.USER -> "user"
                MessageRole.ASSISTANT -> "model" // Gemini requires "model" for assistant turns
                MessageRole.SYSTEM -> continue
            }

            val turnObj = JSONObject()
            turnObj.put("role", role)
            val partsArray = JSONArray()
            partsArray.put(JSONObject().put("text", item.content))
            turnObj.put("parts", partsArray)
            contentsArray.put(turnObj)
        }

        // Fallback if empty
        if (contentsArray.length() == 0) {
            val fallback = JSONObject()
            fallback.put("role", "user")
            fallback.put("parts", JSONArray().put(JSONObject().put("text", "Hello")))
            contentsArray.put(fallback)
        }

        root.put("contents", contentsArray)

        // 2. System Instruction
        if (systemInstruction.isNotBlank()) {
            val sysObj = JSONObject()
            val sysParts = JSONArray()
            sysParts.put(JSONObject().put("text", systemInstruction))
            sysObj.put("parts", sysParts)
            root.put("system_instruction", sysObj)
        }

        // 3. Generation Config
        val genConfig = JSONObject()
        genConfig.put("temperature", 0.7)
        root.put("generationConfig", genConfig)

        return root
    }

    private fun extractGeminiChunkText(jsonString: String): String? {
        return try {
            val json = JSONObject(jsonString)
            val candidates = json.optJSONArray("candidates") ?: return null
            if (candidates.length() == 0) return null

            val firstCandidate = candidates.optJSONObject(0) ?: return null
            val content = firstCandidate.optJSONObject("content") ?: return null
            val parts = content.optJSONArray("parts") ?: return null
            if (parts.length() == 0) return null

            val firstPart = parts.optJSONObject(0) ?: return null
            firstPart.optString("text", null)
        } catch (_: Exception) {
            null
        }
    }

    private fun parseGeminiNonStreamingResponse(jsonString: String): String {
        return try {
            val json = JSONObject(jsonString)
            val candidates = json.optJSONArray("candidates") ?: return ""
            if (candidates.length() == 0) return ""

            val firstCandidate = candidates.optJSONObject(0) ?: return ""
            val content = firstCandidate.optJSONObject("content") ?: return ""
            val parts = content.optJSONArray("parts") ?: return ""
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val part = parts.optJSONObject(i)
                part?.optString("text")?.let { sb.append(it) }
            }
            sb.toString().trim()
        } catch (_: Exception) {
            ""
        }
    }

    private fun parseHttpError(code: Int, errorBody: String, modelName: String): String {
        var apiMessage = ""
        try {
            val json = JSONObject(errorBody)
            val errorObj = json.optJSONObject("error")
            if (errorObj != null) {
                apiMessage = errorObj.optString("message", "")
            }
        } catch (_: Exception) {}

        return when (code) {
            400, 403 -> {
                if (apiMessage.contains("API key", ignoreCase = true) || apiMessage.contains("PERMISSION_DENIED", ignoreCase = true)) {
                    "Invalid Google Gemini API Key. Please verify your key in Settings → AI Provider."
                } else if (apiMessage.isNotBlank()) {
                    "Google Gemini Error: $apiMessage"
                } else {
                    "Invalid API Key or unauthorized request. Please check Settings → AI Provider."
                }
            }
            404 -> "Model '$modelName' was not found. Please verify the model name in Settings → AI Provider (e.g., gemini-2.5-flash)."
            429 -> "Gemini API quota or rate limit exceeded. Please wait a moment or check your AI Studio quotas."
            500, 503 -> "Google Gemini server is currently busy. Please try again in a few moments."
            else -> if (apiMessage.isNotBlank()) apiMessage else "AI Provider error ($code). Check your connection and settings."
        }
    }

    companion object {
        private const val TAG = "ConfigurableAIService"

        @Volatile
        private var defaultInstance: ConfigurableAIServiceImpl? = null

        fun getInstance(storage: SecureAIProviderStorage? = null): ConfigurableAIServiceImpl {
            return defaultInstance ?: synchronized(this) {
                defaultInstance ?: run {
                    val resolvedStorage = storage ?: SecureAIProviderStorage.getInstance()
                    ConfigurableAIServiceImpl(resolvedStorage).also { defaultInstance = it }
                }
            }
        }
    }
}
