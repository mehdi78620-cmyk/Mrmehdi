package com.example.data.config

/**
 * Data class representing all user configurable preferences in Muskan AI Settings.
 */
data class AppSettings(
    // 1. AI Response Settings
    val responseStyle: String = "Balanced", // Balanced, Concise, Detailed, Creative
    val temperature: Float = 0.7f,
    val responseLanguage: String = "Auto", // Auto, Hindi, Hinglish, English

    // 2. Voice Settings
    val voiceEnabled: Boolean = true,
    val speechRecognitionLanguage: String = "Auto",
    val ttsEnabled: Boolean = true,
    val voiceSpeed: Float = 1.0f,
    val voicePitch: Float = 1.0f,

    // 3. Personalization
    val assistantName: String = "Muskan AI",
    val userName: String = "User",
    val personalInstructions: String = "Always respond with warmth, clarity, and helpfulness.",
    val personalityStyle: String = "Friendly", // Friendly, Professional, Casual, Helpful, Custom

    // 4. Memory Settings
    val memoryEnabled: Boolean = true,

    // 5. Appearance Settings
    val darkTheme: Boolean = true,
    val neonIntensity: Float = 1.0f,
    val animationsEnabled: Boolean = true,
    val reduceAnimations: Boolean = false
) {
    companion object {
        val STYLES = listOf("Balanced", "Concise", "Detailed", "Creative")
        val LANGUAGES = listOf("Auto", "Hindi", "Hinglish", "English")
        val PERSONALITIES = listOf("Friendly", "Professional", "Casual", "Helpful", "Custom")
        val SPEECH_LANGUAGES = listOf("Auto", "English (US)", "Hindi (India)", "Hinglish")
    }
}
