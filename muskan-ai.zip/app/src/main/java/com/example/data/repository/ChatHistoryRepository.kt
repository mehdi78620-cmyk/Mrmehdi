package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.dao.ChatMessageDao
import com.example.data.local.dao.ConversationDao
import com.example.data.local.entity.ChatMessageEntity
import com.example.data.local.entity.ConversationEntity
import com.example.data.model.ChatMessageItem
import com.example.data.model.MessageRole
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.util.UUID

interface ChatHistoryRepository {
    fun getAllConversationsFlow(): Flow<List<ConversationEntity>>
    suspend fun getConversationById(id: String): ConversationEntity?
    suspend fun createNewConversation(title: String = "New Chat"): ConversationEntity
    suspend fun saveUserMessage(conversationId: String, text: String): ChatMessageEntity
    suspend fun saveAssistantMessage(conversationId: String, text: String, messageId: String? = null): ChatMessageEntity
    suspend fun getMessages(conversationId: String): List<ChatMessageItem>
    fun getMessagesFlow(conversationId: String): Flow<List<ChatMessageItem>>
    suspend fun updateTitle(conversationId: String, newTitle: String)
    suspend fun deleteConversation(conversationId: String)
    suspend fun deleteAllConversations()
}

class ChatHistoryRepositoryImpl(
    private val conversationDao: ConversationDao,
    private val chatMessageDao: ChatMessageDao
) : ChatHistoryRepository {

    override fun getAllConversationsFlow(): Flow<List<ConversationEntity>> {
        return conversationDao.getAllConversationsFlow()
    }

    override suspend fun getConversationById(id: String): ConversationEntity? = withContext(Dispatchers.IO) {
        conversationDao.getConversationById(id)
    }

    override suspend fun createNewConversation(title: String): ConversationEntity = withContext(Dispatchers.IO) {
        val newConv = ConversationEntity(
            id = UUID.randomUUID().toString(),
            title = title,
            createdAt = System.currentTimeMillis(),
            updatedAt = System.currentTimeMillis(),
            messageCount = 0,
            lastSnippet = ""
        )
        conversationDao.insertOrUpdate(newConv)
        newConv
    }

    override suspend fun saveUserMessage(conversationId: String, text: String): ChatMessageEntity = withContext(Dispatchers.IO) {
        val entity = ChatMessageEntity(
            id = UUID.randomUUID().toString(),
            conversationId = conversationId,
            role = MessageRole.USER.toApiRole(),
            content = text,
            timestamp = System.currentTimeMillis()
        )
        chatMessageDao.insertMessage(entity)

        // Update conversation metadata
        val allMessages = chatMessageDao.getMessagesForConversation(conversationId)
        val snippet = if (text.length > 80) text.take(77) + "..." else text
        conversationDao.updateConversationMeta(
            id = conversationId,
            updatedAt = System.currentTimeMillis(),
            messageCount = allMessages.size,
            lastSnippet = snippet
        )
        entity
    }

    override suspend fun saveAssistantMessage(
        conversationId: String,
        text: String,
        messageId: String?
    ): ChatMessageEntity = withContext(Dispatchers.IO) {
        val entity = ChatMessageEntity(
            id = messageId ?: UUID.randomUUID().toString(),
            conversationId = conversationId,
            role = MessageRole.ASSISTANT.toApiRole(),
            content = text,
            timestamp = System.currentTimeMillis()
        )
        chatMessageDao.insertMessage(entity)

        val allMessages = chatMessageDao.getMessagesForConversation(conversationId)
        val snippet = if (text.length > 80) text.take(77) + "..." else text
        conversationDao.updateConversationMeta(
            id = conversationId,
            updatedAt = System.currentTimeMillis(),
            messageCount = allMessages.size,
            lastSnippet = snippet
        )
        entity
    }

    override suspend fun getMessages(conversationId: String): List<ChatMessageItem> = withContext(Dispatchers.IO) {
        chatMessageDao.getMessagesForConversation(conversationId).map { entity ->
            ChatMessageItem(
                id = entity.id,
                role = MessageRole.fromString(entity.role),
                content = entity.content,
                timestamp = entity.timestamp
            )
        }
    }

    override fun getMessagesFlow(conversationId: String): Flow<List<ChatMessageItem>> {
        return chatMessageDao.getMessagesFlowForConversation(conversationId).map { list ->
            list.map { entity ->
                ChatMessageItem(
                    id = entity.id,
                    role = MessageRole.fromString(entity.role),
                    content = entity.content,
                    timestamp = entity.timestamp
                )
            }
        }
    }

    override suspend fun updateTitle(conversationId: String, newTitle: String) = withContext(Dispatchers.IO) {
        conversationDao.updateTitle(conversationId, newTitle)
    }

    override suspend fun deleteConversation(conversationId: String) = withContext(Dispatchers.IO) {
        chatMessageDao.deleteMessagesForConversation(conversationId)
        conversationDao.deleteConversationById(conversationId)
    }

    override suspend fun deleteAllConversations() = withContext(Dispatchers.IO) {
        conversationDao.deleteAllConversations()
    }

    companion object {
        @Volatile
        private var instance: ChatHistoryRepository? = null

        fun getInstance(database: AppDatabase = AppDatabase.getInstance()): ChatHistoryRepository {
            return instance ?: synchronized(this) {
                instance ?: ChatHistoryRepositoryImpl(
                    conversationDao = database.conversationDao(),
                    chatMessageDao = database.chatMessageDao()
                ).also { instance = it }
            }
        }
    }
}
