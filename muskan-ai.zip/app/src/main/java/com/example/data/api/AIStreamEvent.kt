package com.example.data.api

/**
 * Events emitted by the AIService during streaming response generation.
 */
sealed interface AIStreamEvent {
    /**
     * An incremental text chunk received from the streaming backend.
     */
    data class Chunk(val text: String) : AIStreamEvent

    /**
     * Generation has completed successfully with the full aggregated text.
     */
    data class Complete(val fullText: String) : AIStreamEvent

    /**
     * An error occurred during request dispatch or response streaming.
     */
    data class Error(
        val throwable: Throwable,
        val userFriendlyMessage: String
    ) : AIStreamEvent
}
