package com.example.data.manager

import com.example.data.api.AIService
import com.example.data.api.AIStreamEvent
import com.example.data.api.ConfigurableAIServiceImpl
import com.example.data.config.AIConfig
import com.example.data.model.ChatMessageItem
import com.example.data.model.MessageRole
import com.example.data.repository.ChatHistoryRepository
import com.example.data.repository.ChatHistoryRepositoryImpl
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Collections
import java.util.UUID

/**
 * Manages the multi-turn conversational context, persistent chat history,
 * structured memory injection, and communication with [AIService].
 */
class ConversationManager(
    private val aiService: AIService = ConfigurableAIServiceImpl.getInstance(),
    private val historyRepository: ChatHistoryRepository = ChatHistoryRepositoryImpl.getInstance(),
    val memoryManager: MemoryManager = MemoryManager.getInstance()
) {
    private val _history = Collections.synchronizedList(mutableListOf<ChatMessageItem>())
    private val scope = CoroutineScope(Dispatchers.IO)

    @Volatile
    var activeConversationId: String = UUID.randomUUID().toString()
        private set

    @Volatile
    var activeConversationTitle: String = "New Chat"
        private set

    init {
        // Setup initial in-memory conversation
        resetConversationInMemory()
    }

    private fun resetConversationInMemory() {
        synchronized(_history) {
            _history.clear()
            _history.add(
                ChatMessageItem(
                    role = MessageRole.ASSISTANT,
                    content = "Hi Jaan ❤️ Main Muskan hoon... aapka personal AI assistant. Aaj main aapki kya madad kar sakti hoon?"
                )
            )
        }
    }

    /**
     * Initializes or creates a persistent conversation session in Room.
     */
    suspend fun ensureActiveConversation(): String = withContext(Dispatchers.IO) {
        val existing = historyRepository.getConversationById(activeConversationId)
        if (existing == null) {
            val created = historyRepository.createNewConversation(activeConversationTitle)
            activeConversationId = created.id
            activeConversationTitle = created.title

            // Save initial assistant greeting
            val greeting = getHistory().firstOrNull()?.content
                ?: "Hi Jaan ❤️ Main Muskan hoon... aapka personal AI assistant."
            historyRepository.saveAssistantMessage(activeConversationId, greeting)
        }
        activeConversationId
    }

    /**
     * Starts a new conversation: creates a new record in local storage and resets context.
     */
    suspend fun startNewConversation(title: String = "New Chat"): String = withContext(Dispatchers.IO) {
        val newConv = historyRepository.createNewConversation(title)
        activeConversationId = newConv.id
        activeConversationTitle = newConv.title

        resetConversationInMemory()

        val greeting = getHistory().first().content
        historyRepository.saveAssistantMessage(activeConversationId, greeting)
        activeConversationId
    }

    /**
     * Loads an existing conversation from local storage into the active in-memory context.
     */
    suspend fun loadConversation(conversationId: String): Boolean = withContext(Dispatchers.IO) {
        val conv = historyRepository.getConversationById(conversationId) ?: return@withContext false
        val savedMessages = historyRepository.getMessages(conversationId)

        activeConversationId = conv.id
        activeConversationTitle = conv.title

        synchronized(_history) {
            _history.clear()
            if (savedMessages.isNotEmpty()) {
                _history.addAll(savedMessages)
            } else {
                _history.add(
                    ChatMessageItem(
                        role = MessageRole.ASSISTANT,
                        content = "Hi Jaan ❤️ Main Muskan hoon... aapka personal AI assistant. Kaise madad kar sakti hoon?"
                    )
                )
            }
        }
        true
    }

    /**
     * Returns an unmodifiable snapshot of the current conversation context.
     */
    fun getHistory(): List<ChatMessageItem> {
        return synchronized(_history) {
            _history.toList()
        }
    }

    /**
     * Appends a user message to the conversation context, persists it locally,
     * and automatically updates conversation title and memory if relevant.
     */
    fun addUserMessage(text: String): ChatMessageItem {
        val userItem = ChatMessageItem(
            role = MessageRole.USER,
            content = text.trim()
        )
        synchronized(_history) {
            _history.add(userItem)
        }

        // Persist to Room in background
        scope.launch {
            ensureActiveConversation()
            historyRepository.saveUserMessage(activeConversationId, userItem.content)

            // Auto-generate a readable conversation title from the first user query
            if (activeConversationTitle == "New Chat" || activeConversationTitle.isBlank()) {
                val candidateTitle = generateTitleFromMessage(userItem.content)
                activeConversationTitle = candidateTitle
                historyRepository.updateTitle(activeConversationId, candidateTitle)
            }

            // Detect potential user preference (e.g. "My name is ...", "I prefer Hinglish")
            val prefCandidate = memoryManager.detectPreferenceCandidate(userItem.content)
            if (prefCandidate != null) {
                memoryManager.savePreference(
                    key = prefCandidate.first,
                    value = prefCandidate.second,
                    category = com.example.data.local.entity.MemoryEntity.CATEGORY_PREFERENCE,
                    source = "Conversation"
                )
            }
        }

        return userItem
    }

    /**
     * Sends the current conversation context along with dynamic memory context
     * through [AIService] to get a streaming response.
     */
    fun streamResponse(): Flow<AIStreamEvent> = flow {
        // 1. Gather dynamic user-approved memory context
        val memoryContext = memoryManager.getMemoryContextForAI()
        val compositeSystemInstruction = AIConfig.MUSKAN_SYSTEM_PROMPT + memoryContext

        val currentHistory = getHistory()
        aiService.sendMessageStream(
            messages = currentHistory,
            systemInstruction = compositeSystemInstruction
        ).collect { event ->
            emit(event)
        }
    }

    /**
     * Records or updates the assistant response once completed, and persists to Room.
     */
    fun recordAiResponse(id: String, content: String): ChatMessageItem {
        val item = ChatMessageItem(
            id = id,
            role = MessageRole.ASSISTANT,
            content = content.trim()
        )
        synchronized(_history) {
            _history.add(item)
        }

        // Persist to Room
        scope.launch {
            ensureActiveConversation()
            historyRepository.saveAssistantMessage(activeConversationId, item.content, item.id)
        }

        return item
    }

    /**
     * Removes the last assistant turn if it resulted in an error so it doesn't pollute context.
     */
    fun removeLastIfFailed(messageId: String) {
        synchronized(_history) {
            val iterator = _history.iterator()
            while (iterator.hasNext()) {
                val item = iterator.next()
                if (item.id == messageId) {
                    iterator.remove()
                    break
                }
            }
        }
    }

    /**
     * Resets active conversation back to initial state and creates a new saved session.
     */
    fun resetConversation() {
        resetConversationInMemory()
        scope.launch {
            startNewConversation("New Chat")
        }
    }

    /**
     * Deletes a conversation by ID.
     */
    suspend fun deleteConversation(conversationId: String) = withContext(Dispatchers.IO) {
        historyRepository.deleteConversation(conversationId)
        if (conversationId == activeConversationId) {
            startNewConversation("New Chat")
        }
    }

    private fun generateTitleFromMessage(userPrompt: String): String {
        val clean = userPrompt.trim()
            .replace("\n", " ")
            .replace(Regex("^(hi|hello|hey|muskan|namaste|sun|batao)\\s*,?\\s*", RegexOption.IGNORE_CASE), "")
            .trim()
        val title = if (clean.length > 36) {
            clean.take(33).trim() + "..."
        } else if (clean.isNotEmpty()) {
            clean.replaceFirstChar { it.uppercase() }
        } else {
            "Chat with Muskan"
        }
        return title
    }

    companion object {
        @Volatile
        private var instance: ConversationManager? = null

        fun getInstance(): ConversationManager {
            return instance ?: synchronized(this) {
                instance ?: ConversationManager().also { instance = it }
            }
        }
    }
}
