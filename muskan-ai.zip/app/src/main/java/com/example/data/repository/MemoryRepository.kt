package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.dao.MemoryDao
import com.example.data.local.entity.MemoryEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.util.UUID

interface MemoryRepository {
    fun getAllApprovedMemoriesFlow(): Flow<List<MemoryEntity>>
    suspend fun getAllApprovedMemories(): List<MemoryEntity>
    fun getMemoriesByCategoryFlow(category: String): Flow<List<MemoryEntity>>
    suspend fun saveMemory(
        key: String,
        value: String,
        category: String = MemoryEntity.CATEGORY_PREFERENCE,
        source: String = "User"
    ): MemoryEntity
    suspend fun updateMemory(memory: MemoryEntity)
    suspend fun deleteMemory(id: String)
    suspend fun clearAllMemories()
    fun countApprovedMemoriesFlow(): Flow<Int>
}

class MemoryRepositoryImpl(
    private val memoryDao: MemoryDao
) : MemoryRepository {

    override fun getAllApprovedMemoriesFlow(): Flow<List<MemoryEntity>> {
        return memoryDao.getAllApprovedMemoriesFlow()
    }

    override suspend fun getAllApprovedMemories(): List<MemoryEntity> = withContext(Dispatchers.IO) {
        memoryDao.getAllApprovedMemories()
    }

    override fun getMemoriesByCategoryFlow(category: String): Flow<List<MemoryEntity>> {
        return memoryDao.getMemoriesByCategoryFlow(category)
    }

    override suspend fun saveMemory(
        key: String,
        value: String,
        category: String,
        source: String
    ): MemoryEntity = withContext(Dispatchers.IO) {
        val existing = memoryDao.getMemoryByKey(key.trim())
        val entity = if (existing != null) {
            existing.copy(
                value = value.trim(),
                category = category,
                source = source,
                updatedAt = System.currentTimeMillis()
            ).also { memoryDao.updateMemory(it) }
        } else {
            MemoryEntity(
                id = UUID.randomUUID().toString(),
                key = key.trim(),
                value = value.trim(),
                category = category,
                source = source,
                isApproved = true,
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            ).also { memoryDao.insertMemory(it) }
        }
        entity
    }

    override suspend fun updateMemory(memory: MemoryEntity) = withContext(Dispatchers.IO) {
        memoryDao.updateMemory(memory)
    }

    override suspend fun deleteMemory(id: String) = withContext(Dispatchers.IO) {
        memoryDao.deleteMemoryById(id)
    }

    override suspend fun clearAllMemories() = withContext(Dispatchers.IO) {
        memoryDao.clearAllMemories()
    }

    override fun countApprovedMemoriesFlow(): Flow<Int> {
        return memoryDao.countApprovedMemoriesFlow()
    }

    companion object {
        @Volatile
        private var instance: MemoryRepository? = null

        fun getInstance(database: AppDatabase = AppDatabase.getInstance()): MemoryRepository {
            return instance ?: synchronized(this) {
                instance ?: MemoryRepositoryImpl(
                    memoryDao = database.memoryDao()
                ).also { instance = it }
            }
        }
    }
}
