package com.example.data.storage

import android.content.Context
import android.content.SharedPreferences
import com.example.data.config.AppSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Secure local storage for general AppSettings using SharedPreferences.
 * Exposes a reactive StateFlow so changes in settings immediately propagate across the app.
 */
class SettingsStorage private constructor(context: Context) {

    private val prefs: SharedPreferences = context.applicationContext.getSharedPreferences(
        PREFS_NAME,
        Context.MODE_PRIVATE
    )

    private val _settingsFlow = MutableStateFlow(loadSettingsInternal())
    val settingsFlow: StateFlow<AppSettings> = _settingsFlow.asStateFlow()

    fun getSettings(): AppSettings {
        return _settingsFlow.value
    }

    @Synchronized
    fun saveSettings(settings: AppSettings) {
        prefs.edit()
            .putString(KEY_RESPONSE_STYLE, settings.responseStyle)
            .putFloat(KEY_TEMPERATURE, settings.temperature)
            .putString(KEY_RESPONSE_LANG, settings.responseLanguage)
            .putBoolean(KEY_VOICE_ENABLED, settings.voiceEnabled)
            .putString(KEY_SPEECH_LANG, settings.speechRecognitionLanguage)
            .putBoolean(KEY_TTS_ENABLED, settings.ttsEnabled)
            .putFloat(KEY_VOICE_SPEED, settings.voiceSpeed)
            .putFloat(KEY_VOICE_PITCH, settings.voicePitch)
            .putString(KEY_ASSISTANT_NAME, settings.assistantName)
            .putString(KEY_USER_NAME, settings.userName)
            .putString(KEY_PERSONAL_INSTRUCTIONS, settings.personalInstructions)
            .putString(KEY_PERSONALITY_STYLE, settings.personalityStyle)
            .putBoolean(KEY_MEMORY_ENABLED, settings.memoryEnabled)
            .putBoolean(KEY_DARK_THEME, settings.darkTheme)
            .putFloat(KEY_NEON_INTENSITY, settings.neonIntensity)
            .putBoolean(KEY_ANIMATIONS_ENABLED, settings.animationsEnabled)
            .putBoolean(KEY_REDUCE_ANIMATIONS, settings.reduceAnimations)
            .apply()

        _settingsFlow.value = settings
    }

    @Synchronized
    fun resetToDefaults() {
        prefs.edit().clear().apply()
        _settingsFlow.value = AppSettings()
    }

    private fun loadSettingsInternal(): AppSettings {
        return AppSettings(
            responseStyle = prefs.getString(KEY_RESPONSE_STYLE, "Balanced") ?: "Balanced",
            temperature = prefs.getFloat(KEY_TEMPERATURE, 0.7f),
            responseLanguage = prefs.getString(KEY_RESPONSE_LANG, "Auto") ?: "Auto",
            voiceEnabled = prefs.getBoolean(KEY_VOICE_ENABLED, true),
            speechRecognitionLanguage = prefs.getString(KEY_SPEECH_LANG, "Auto") ?: "Auto",
            ttsEnabled = prefs.getBoolean(KEY_TTS_ENABLED, true),
            voiceSpeed = prefs.getFloat(KEY_VOICE_SPEED, 1.0f),
            voicePitch = prefs.getFloat(KEY_VOICE_PITCH, 1.0f),
            assistantName = prefs.getString(KEY_ASSISTANT_NAME, "Muskan AI") ?: "Muskan AI",
            userName = prefs.getString(KEY_USER_NAME, "User") ?: "User",
            personalInstructions = prefs.getString(KEY_PERSONAL_INSTRUCTIONS, "Always respond with warmth, clarity, and helpfulness.") ?: "Always respond with warmth, clarity, and helpfulness.",
            personalityStyle = prefs.getString(KEY_PERSONALITY_STYLE, "Friendly") ?: "Friendly",
            memoryEnabled = prefs.getBoolean(KEY_MEMORY_ENABLED, true),
            darkTheme = prefs.getBoolean(KEY_DARK_THEME, true),
            neonIntensity = prefs.getFloat(KEY_NEON_INTENSITY, 1.0f),
            animationsEnabled = prefs.getBoolean(KEY_ANIMATIONS_ENABLED, true),
            reduceAnimations = prefs.getBoolean(KEY_REDUCE_ANIMATIONS, false)
        )
    }

    companion object {
        private const val PREFS_NAME = "muskan_ai_settings_store"

        private const val KEY_RESPONSE_STYLE = "response_style"
        private const val KEY_TEMPERATURE = "temperature"
        private const val KEY_RESPONSE_LANG = "response_lang"
        private const val KEY_VOICE_ENABLED = "voice_enabled"
        private const val KEY_SPEECH_LANG = "speech_lang"
        private const val KEY_TTS_ENABLED = "tts_enabled"
        private const val KEY_VOICE_SPEED = "voice_speed"
        private const val KEY_VOICE_PITCH = "voice_pitch"
        private const val KEY_ASSISTANT_NAME = "assistant_name"
        private const val KEY_USER_NAME = "user_name"
        private const val KEY_PERSONAL_INSTRUCTIONS = "personal_instructions"
        private const val KEY_PERSONALITY_STYLE = "personality_style"
        private const val KEY_MEMORY_ENABLED = "memory_enabled"
        private const val KEY_DARK_THEME = "dark_theme"
        private const val KEY_NEON_INTENSITY = "neon_intensity"
        private const val KEY_ANIMATIONS_ENABLED = "animations_enabled"
        private const val KEY_REDUCE_ANIMATIONS = "reduce_animations"

        @Volatile
        private var instance: SettingsStorage? = null

        fun init(context: Context): SettingsStorage {
            return instance ?: synchronized(this) {
                instance ?: SettingsStorage(context.applicationContext).also { instance = it }
            }
        }

        fun getInstance(context: Context? = null): SettingsStorage {
            instance?.let { return it }
            return synchronized(this) {
                instance ?: run {
                    if (context != null) {
                        SettingsStorage(context.applicationContext).also { instance = it }
                    } else {
                        try {
                            val app = Class.forName("android.app.ActivityThread")
                                .getMethod("currentApplication")
                                .invoke(null) as? Context
                            if (app != null) {
                                return@run SettingsStorage(app).also { instance = it }
                            }
                        } catch (_: Exception) {}

                        try {
                            val appProviderClass = Class.forName("androidx.test.core.app.ApplicationProvider")
                            val testContext = appProviderClass
                                .getMethod("getApplicationContext")
                                .invoke(null) as? Context
                            if (testContext != null) {
                                return@run SettingsStorage(testContext).also { instance = it }
                            }
                        } catch (_: Exception) {}

                        throw IllegalStateException("SettingsStorage must be initialized with Context before use.")
                    }
                }
            }
        }
    }
}
