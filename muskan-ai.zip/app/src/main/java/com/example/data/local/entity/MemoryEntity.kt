package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

/**
 * Structured memory entity representing user-approved preferences and context.
 * Strictly avoids storing sensitive information (credentials, financial/health data).
 */
@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val key: String,
    val value: String,
    val category: String = CATEGORY_PREFERENCE,
    val source: String = "User",
    val isApproved: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    companion object {
        const val CATEGORY_PREFERENCE = "Preference"
        const val CATEGORY_IDENTITY = "Identity"
        const val CATEGORY_INTEREST = "Interest"
        const val CATEGORY_FACT = "Fact"

        val ALL_CATEGORIES = listOf(
            CATEGORY_PREFERENCE,
            CATEGORY_IDENTITY,
            CATEGORY_INTEREST,
            CATEGORY_FACT
        )
    }
}
