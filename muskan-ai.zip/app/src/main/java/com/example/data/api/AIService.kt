package com.example.data.api

import com.example.data.model.ChatMessageItem
import kotlinx.coroutines.flow.Flow

/**
 * Interface defining communication with the AI backend service.
 * Isolates the AI model, provider, and transport protocol from the rest of the application.
 */
interface AIService {

    /**
     * Sends the conversation context to the backend and yields real-time streaming tokens.
     *
     * @param messages Multi-turn conversation history up to the latest user message.
     * @param systemInstruction System persona and behavioral prompt.
     * @return Flow emitting [AIStreamEvent.Chunk], [AIStreamEvent.Complete], or [AIStreamEvent.Error].
     */
    fun sendMessageStream(
        messages: List<ChatMessageItem>,
        systemInstruction: String
    ): Flow<AIStreamEvent>

    /**
     * Non-streaming request that returns the full response once completed.
     *
     * @param messages Multi-turn conversation history.
     * @param systemInstruction System prompt.
     * @return Result containing either the AI text reply or an exception.
     */
    suspend fun sendMessage(
        messages: List<ChatMessageItem>,
        systemInstruction: String
    ): Result<String>
}
