package com.example.data.config

/**
 * Domain model representing the user's configured AI Provider.
 *
 * Supported parameters:
 * - Provider name (Google Gemini by default)
 * - API Key (stored securely on device, masked in the UI)
 * - Model name (e.g. gemini-2.5-flash, gemini-1.5-flash)
 * - Optional Base URL (for official endpoints or custom reverse proxies)
 * - Connection test status & timestamp
 */
data class AIProviderConfig(
    val providerName: String = PROVIDER_GOOGLE_GEMINI,
    val apiKey: String = "",
    val modelName: String = DEFAULT_GEMINI_MODEL,
    val baseUrl: String? = null,
    val lastTestStatus: String = STATUS_NOT_CONFIGURED,
    val lastTestTimestamp: Long = 0L
) {
    /**
     * Whether the provider has an API key configured.
     */
    val isConfigured: Boolean
        get() = apiKey.isNotBlank()

    /**
     * Returns the active base URL, falling back to Google Gemini's standard endpoint if unset.
     */
    fun getEffectiveBaseUrl(): String {
        val custom = baseUrl?.trim()
        if (!custom.isNullOrBlank()) {
            return if (custom.endsWith("/")) custom else "$custom/"
        }
        return DEFAULT_GEMINI_BASE_URL
    }

    /**
     * Masks the API key for safe UI display (e.g., AIza••••••••abcd).
     */
    fun getMaskedApiKey(): String {
        val trimmed = apiKey.trim()
        if (trimmed.isEmpty()) return ""
        return if (trimmed.length <= 8) {
            "••••••••"
        } else {
            "${trimmed.take(4)}••••••••${trimmed.takeLast(4)}"
        }
    }

    companion object {
        const val PROVIDER_GOOGLE_GEMINI = "Google Gemini"
        const val DEFAULT_GEMINI_MODEL = "gemini-2.5-flash"
        const val DEFAULT_GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/"

        const val STATUS_NOT_CONFIGURED = "Not Configured"
        const val STATUS_TESTING = "Testing Connection..."
        const val STATUS_CONNECTED = "Connected"
        const val STATUS_FAILED = "Connection Failed"

        val POPULAR_GEMINI_MODELS = listOf(
            "gemini-2.5-flash",
            "gemini-1.5-flash",
            "gemini-1.5-pro"
        )
    }
}
