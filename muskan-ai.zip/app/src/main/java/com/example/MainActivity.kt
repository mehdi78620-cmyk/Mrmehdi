package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.data.storage.SecureAIProviderStorage
import com.example.navigation.AppNavigation
import com.example.ui.theme.MuskanAITheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    SecureAIProviderStorage.initialize(applicationContext)
    com.example.data.local.AppDatabase.initialize(applicationContext)
    enableEdgeToEdge()
    setContent {
      MuskanAITheme {
        AppNavigation()
      }
    }
  }
}
