package com.example.navigation

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.ComingNextScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.settings.AboutSettingsScreen
import com.example.ui.screens.settings.AIProviderSettingsScreen
import com.example.ui.screens.settings.AiResponseSettingsScreen
import com.example.ui.screens.settings.AppearanceSettingsScreen
import com.example.ui.screens.settings.MemorySettingsScreen
import com.example.ui.screens.settings.PersonalizationSettingsScreen
import com.example.ui.screens.settings.PrivacyPermissionsSettingsScreen
import com.example.ui.screens.settings.VoiceSettingsScreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonPink
import com.example.ui.theme.NeonPinkGlow
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonPurpleGlow

object AppDestinations {
    const val HOME = "home"
    const val CHAT = "chat"
    const val CHAT_WITH_ID = "chat/{conversationId}"
    const val HISTORY = "history"
    const val MEMORY = "memory"
    const val SETTINGS = "settings"
    const val AI_PROVIDER = "ai_provider"
    const val AI_RESPONSE = "ai_response"
    const val VOICE_SETTINGS = "voice_settings"
    const val PERSONALIZATION = "personalization"
    const val APPEARANCE = "appearance"
    const val PRIVACY = "privacy"
    const val ABOUT = "about"
    const val WEB_SEARCH = "web_search"
    const val CODING = "coding"
    const val CREATE_IMAGE = "create_image"
    const val VOICE = "voice"
    const val CAMERA = "camera"
    const val FILES = "files"
    const val MORE = "more"
}

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    Scaffold(
        containerColor = DarkBackground,
        modifier = Modifier.fillMaxSize()
    ) { _ ->
        NavHost(
            navController = navController,
            startDestination = AppDestinations.HOME,
            modifier = Modifier.fillMaxSize()
        ) {
            composable(AppDestinations.HOME) {
                HomeScreen(
                    onNavigateToChat = { navController.navigate(AppDestinations.CHAT) },
                    onNavigateToHistory = { navController.navigate(AppDestinations.HISTORY) },
                    onNavigateToSettings = { navController.navigate(AppDestinations.SETTINGS) },
                    onNavigateToWebSearch = { navController.navigate(AppDestinations.WEB_SEARCH) },
                    onNavigateToCoding = { navController.navigate(AppDestinations.CODING) },
                    onNavigateToCreateImage = { navController.navigate(AppDestinations.CREATE_IMAGE) },
                    onNavigateToVoice = { navController.navigate(AppDestinations.VOICE) },
                    onNavigateToCamera = { navController.navigate(AppDestinations.CAMERA) },
                    onNavigateToFiles = { navController.navigate(AppDestinations.FILES) },
                    onNavigateToMore = { navController.navigate(AppDestinations.MORE) },
                    onMenuClick = { navController.navigate(AppDestinations.MORE) }
                )
            }

            composable(AppDestinations.CHAT) {
                ChatScreen(
                    onBackClick = { navController.popBackStack() },
                    onNavigateToSettings = { navController.navigate(AppDestinations.AI_PROVIDER) },
                    onNavigateToHistory = { navController.navigate(AppDestinations.HISTORY) },
                    onNavigateToMemory = { navController.navigate(AppDestinations.MEMORY) }
                )
            }

            composable(
                route = AppDestinations.CHAT_WITH_ID,
                arguments = listOf(navArgument("conversationId") { type = NavType.StringType })
            ) { backStackEntry ->
                val conversationId = backStackEntry.arguments?.getString("conversationId")
                ChatScreen(
                    conversationId = conversationId,
                    onBackClick = { navController.popBackStack() },
                    onNavigateToSettings = { navController.navigate(AppDestinations.AI_PROVIDER) },
                    onNavigateToHistory = { navController.navigate(AppDestinations.HISTORY) },
                    onNavigateToMemory = { navController.navigate(AppDestinations.MEMORY) }
                )
            }

            composable(AppDestinations.HISTORY) {
                HistoryScreen(
                    onBackClick = { navController.popBackStack() },
                    onOpenConversation = { conversationId ->
                        navController.navigate("chat/$conversationId")
                    },
                    onNewChatClick = {
                        navController.navigate(AppDestinations.CHAT)
                    }
                )
            }

            composable(AppDestinations.MEMORY) {
                MemorySettingsScreen(
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(AppDestinations.SETTINGS) {
                SettingsScreen(
                    onBackClick = { navController.popBackStack() },
                    onNavigateToAiProvider = { navController.navigate(AppDestinations.AI_PROVIDER) },
                    onNavigateToAiResponse = { navController.navigate(AppDestinations.AI_RESPONSE) },
                    onNavigateToVoiceSettings = { navController.navigate(AppDestinations.VOICE_SETTINGS) },
                    onNavigateToPersonalization = { navController.navigate(AppDestinations.PERSONALIZATION) },
                    onNavigateToMemory = { navController.navigate(AppDestinations.MEMORY) },
                    onNavigateToAppearance = { navController.navigate(AppDestinations.APPEARANCE) },
                    onNavigateToPrivacy = { navController.navigate(AppDestinations.PRIVACY) },
                    onNavigateToAbout = { navController.navigate(AppDestinations.ABOUT) },
                    onNavigateToHistory = { navController.navigate(AppDestinations.HISTORY) }
                )
            }

            composable(AppDestinations.AI_PROVIDER) {
                AIProviderSettingsScreen(
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(AppDestinations.AI_RESPONSE) {
                AiResponseSettingsScreen(
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(AppDestinations.VOICE_SETTINGS) {
                VoiceSettingsScreen(
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(AppDestinations.PERSONALIZATION) {
                PersonalizationSettingsScreen(
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(AppDestinations.APPEARANCE) {
                AppearanceSettingsScreen(
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(AppDestinations.PRIVACY) {
                PrivacyPermissionsSettingsScreen(
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(AppDestinations.ABOUT) {
                AboutSettingsScreen(
                    onBackClick = { navController.popBackStack() }
                )
            }

            composable(AppDestinations.WEB_SEARCH) {
                ChatScreen(
                    onBackClick = { navController.popBackStack() },
                    onNavigateToSettings = { navController.navigate(AppDestinations.AI_PROVIDER) },
                    onNavigateToHistory = { navController.navigate(AppDestinations.HISTORY) },
                    onNavigateToMemory = { navController.navigate(AppDestinations.MEMORY) }
                )
            }

            composable(AppDestinations.CODING) {
                ChatScreen(
                    onBackClick = { navController.popBackStack() },
                    onNavigateToSettings = { navController.navigate(AppDestinations.AI_PROVIDER) },
                    onNavigateToHistory = { navController.navigate(AppDestinations.HISTORY) },
                    onNavigateToMemory = { navController.navigate(AppDestinations.MEMORY) }
                )
            }

            composable(AppDestinations.CREATE_IMAGE) {
                ChatScreen(
                    onBackClick = { navController.popBackStack() },
                    onNavigateToSettings = { navController.navigate(AppDestinations.AI_PROVIDER) },
                    onNavigateToHistory = { navController.navigate(AppDestinations.HISTORY) },
                    onNavigateToMemory = { navController.navigate(AppDestinations.MEMORY) }
                )
            }

            composable(AppDestinations.VOICE) {
                ChatScreen(
                    startVoiceImmediately = true,
                    onBackClick = { navController.popBackStack() },
                    onNavigateToSettings = { navController.navigate(AppDestinations.AI_PROVIDER) },
                    onNavigateToHistory = { navController.navigate(AppDestinations.HISTORY) },
                    onNavigateToMemory = { navController.navigate(AppDestinations.MEMORY) }
                )
            }

            composable(AppDestinations.CAMERA) {
                ChatScreen(
                    onBackClick = { navController.popBackStack() },
                    onNavigateToSettings = { navController.navigate(AppDestinations.AI_PROVIDER) },
                    onNavigateToHistory = { navController.navigate(AppDestinations.HISTORY) },
                    onNavigateToMemory = { navController.navigate(AppDestinations.MEMORY) }
                )
            }

            composable(AppDestinations.FILES) {
                ChatScreen(
                    onBackClick = { navController.popBackStack() },
                    onNavigateToSettings = { navController.navigate(AppDestinations.AI_PROVIDER) },
                    onNavigateToHistory = { navController.navigate(AppDestinations.HISTORY) },
                    onNavigateToMemory = { navController.navigate(AppDestinations.MEMORY) }
                )
            }

            composable(AppDestinations.MORE) {
                SettingsScreen(
                    onBackClick = { navController.popBackStack() },
                    onNavigateToAiProvider = { navController.navigate(AppDestinations.AI_PROVIDER) },
                    onNavigateToAiResponse = { navController.navigate(AppDestinations.AI_RESPONSE) },
                    onNavigateToVoiceSettings = { navController.navigate(AppDestinations.VOICE_SETTINGS) },
                    onNavigateToPersonalization = { navController.navigate(AppDestinations.PERSONALIZATION) },
                    onNavigateToMemory = { navController.navigate(AppDestinations.MEMORY) },
                    onNavigateToAppearance = { navController.navigate(AppDestinations.APPEARANCE) },
                    onNavigateToPrivacy = { navController.navigate(AppDestinations.PRIVACY) },
                    onNavigateToAbout = { navController.navigate(AppDestinations.ABOUT) },
                    onNavigateToHistory = { navController.navigate(AppDestinations.HISTORY) }
                )
            }
        }
    }
}
