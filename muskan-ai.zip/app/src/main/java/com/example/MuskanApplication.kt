package com.example

import android.app.Application
import com.example.data.local.AppDatabase
import com.example.data.storage.SecureAIProviderStorage

class MuskanApplication : Application() {
    companion object {
        private var _instance: MuskanApplication? = null
        val instance: MuskanApplication
            get() = _instance ?: throw IllegalStateException("MuskanApplication is not initialized")
    }

    override fun onCreate() {
        super.onCreate()
        _instance = this
        SecureAIProviderStorage.initialize(this)
        AppDatabase.initialize(this)
    }
}
