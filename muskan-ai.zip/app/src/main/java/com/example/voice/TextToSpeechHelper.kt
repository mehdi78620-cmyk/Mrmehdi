package com.example.voice

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.UUID

/**
 * Android Text-to-Speech manager for Muskan AI.
 * Handles speech synthesis for AI responses, language detection (Hindi/English/Hinglish),
 * markdown stripping, and playback state tracking.
 */
class TextToSpeechHelper(private val context: Context) : TextToSpeech.OnInitListener {

    private val tag = "TextToSpeechHelper"

    private var tts: TextToSpeech? = null

    private val _isInitialized = MutableStateFlow(false)
    val isInitialized: StateFlow<Boolean> = _isInitialized.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _currentSpeakingUtteranceId = MutableStateFlow<String?>(null)
    val currentSpeakingUtteranceId: StateFlow<String?> = _currentSpeakingUtteranceId.asStateFlow()

    private var onDoneCallback: (() -> Unit)? = null

    init {
        try {
            tts = TextToSpeech(context.applicationContext, this)
        } catch (e: Exception) {
            Log.e(tag, "Failed to instantiate TextToSpeech", e)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val ttsEngine = tts ?: return
            _isInitialized.value = true

            // Set natural, warm conversational pitch and rate for Muskan
            ttsEngine.setPitch(1.05f)
            ttsEngine.setSpeechRate(0.98f)

            ttsEngine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    Log.d(tag, "TTS onStart: $utteranceId")
                    _isSpeaking.value = true
                    _currentSpeakingUtteranceId.value = utteranceId
                }

                override fun onDone(utteranceId: String?) {
                    Log.d(tag, "TTS onDone: $utteranceId")
                    _isSpeaking.value = false
                    _currentSpeakingUtteranceId.value = null
                    onDoneCallback?.invoke()
                    onDoneCallback = null
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    Log.w(tag, "TTS onError: $utteranceId")
                    _isSpeaking.value = false
                    _currentSpeakingUtteranceId.value = null
                    onDoneCallback = null
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    Log.w(tag, "TTS onError code=$errorCode utteranceId=$utteranceId")
                    _isSpeaking.value = false
                    _currentSpeakingUtteranceId.value = null
                    onDoneCallback = null
                }
            })
            Log.d(tag, "TextToSpeech initialized successfully")
        } else {
            Log.e(tag, "TextToSpeech initialization failed with status: $status")
            _isInitialized.value = false
        }
    }

    /**
     * Speaks the given AI response text aloud.
     * Cleans up markdown formatting and auto-selects Hindi vs English locale.
     */
    fun speak(
        text: String,
        utteranceId: String = UUID.randomUUID().toString(),
        preferredLanguage: VoiceLanguage? = null,
        onDone: (() -> Unit)? = null
    ) {
        val ttsEngine = tts
        if (ttsEngine == null || !_isInitialized.value) {
            Log.w(tag, "TTS not initialized yet")
            return
        }

        val cleanedText = cleanTextForSpeech(text)
        if (cleanedText.isBlank()) return

        stop()
        this.onDoneCallback = onDone

        // Determine best matching language
        val targetLocale = when {
            preferredLanguage == VoiceLanguage.HINDI -> Locale.forLanguageTag("hi-IN")
            preferredLanguage == VoiceLanguage.ENGLISH -> Locale.US
            preferredLanguage == VoiceLanguage.HINGLISH -> Locale.forLanguageTag("en-IN")
            containsDevanagari(cleanedText) -> Locale.forLanguageTag("hi-IN")
            else -> Locale.forLanguageTag("en-IN")
        }

        try {
            val langResult = ttsEngine.setLanguage(targetLocale)
            if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Fallback to English / default if Hindi voice pack is missing on device
                Log.w(tag, "Target language $targetLocale not supported, falling back to default")
                ttsEngine.setLanguage(Locale.US)
            }
        } catch (e: Exception) {
            Log.w(tag, "Error setting TTS language", e)
        }

        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
        }

        try {
            _currentSpeakingUtteranceId.value = utteranceId
            _isSpeaking.value = true
            ttsEngine.speak(cleanedText, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
        } catch (e: Exception) {
            Log.e(tag, "Error invoking speak()", e)
            _isSpeaking.value = false
            _currentSpeakingUtteranceId.value = null
        }
    }

    /**
     * Stops any currently active speech playback immediately.
     */
    fun stop() {
        try {
            tts?.stop()
            _isSpeaking.value = false
            _currentSpeakingUtteranceId.value = null
            onDoneCallback = null
        } catch (e: Exception) {
            Log.w(tag, "Error stopping TTS", e)
        }
    }

    /**
     * Cleans markdown characters, code blocks, bullet markers, and URLs
     * so that Android Text-To-Speech speaks natural human sentences.
     */
    fun cleanTextForSpeech(raw: String): String {
        return raw
            // Remove triple backticks from code blocks while keeping content
            .replace("```", " ")
            // Remove inline backticks while keeping code text
            .replace("`", "")
            // Remove markdown links [text](url) -> text
            .replace(Regex("\\[([^\\]]+)\\]\\([^\\)]+\\)"), "$1")
            // Remove bold/italics markers ** * __ _
            .replace(Regex("[*_~]"), "")
            // Remove header markers #
            .replace(Regex("#+"), "")
            // Remove bullet points / dash
            .replace(Regex("^[\\s*•\\-]+\\s*", RegexOption.MULTILINE), "")
            // Replace emojis and symbols that clutter TTS
            .replace(Regex("[❤️✨🌸🤖🔥👍🎉👋😊🙌🙏]"), "")
            // Collapse multiple spaces/newlines
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun containsDevanagari(text: String): Boolean {
        for (char in text) {
            val block = Character.UnicodeBlock.of(char)
            if (block == Character.UnicodeBlock.DEVANAGARI) {
                return true
            }
        }
        return false
    }

    /**
     * Releases TTS resources on cleanup.
     */
    fun shutdown() {
        try {
            stop()
            tts?.shutdown()
            tts = null
            _isInitialized.value = false
        } catch (e: Exception) {
            Log.w(tag, "Error shutting down TTS", e)
        }
    }
}
