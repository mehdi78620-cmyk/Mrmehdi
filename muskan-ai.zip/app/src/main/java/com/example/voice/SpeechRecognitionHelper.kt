package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

/**
 * State representing speech recognition lifecycle.
 */
sealed class SpeechRecognitionState {
    object Idle : SpeechRecognitionState()
    object Initializing : SpeechRecognitionState()
    object Ready : SpeechRecognitionState()
    data class Listening(val rmsDb: Float = 0f) : SpeechRecognitionState()
    data class Recognized(val text: String, val isFinal: Boolean) : SpeechRecognitionState()
    data class Error(val message: String, val errorCode: Int? = null) : SpeechRecognitionState()
}

/**
 * Language choices supported by Muskan AI for voice input.
 */
enum class VoiceLanguage(val displayName: String, val tag: String, val locale: Locale) {
    HINDI("हिंदी", "hi-IN", Locale.forLanguageTag("hi-IN")),
    HINGLISH("Hinglish", "en-IN", Locale.forLanguageTag("en-IN")),
    ENGLISH("English", "en-US", Locale.US);

    companion object {
        fun fromTag(tag: String): VoiceLanguage {
            return entries.find { it.tag.equals(tag, ignoreCase = true) } ?: HINDI
        }
    }
}

/**
 * Native Android SpeechRecognizer wrapper providing reactive state flows,
 * partial live transcription, audio level metering (RMS dB), and multilingual support.
 */
class SpeechRecognitionHelper(private val context: Context) {

    private val tag = "SpeechRecognitionHelper"
    private val mainHandler = Handler(Looper.getMainLooper())

    private var speechRecognizer: SpeechRecognizer? = null
    private var isCurrentlyListening = false

    private val _state = MutableStateFlow<SpeechRecognitionState>(SpeechRecognitionState.Idle)
    val state: StateFlow<SpeechRecognitionState> = _state.asStateFlow()

    private val _rmsLevel = MutableStateFlow(0f)
    val rmsLevel: StateFlow<Float> = _rmsLevel.asStateFlow()

    private val _currentLanguage = MutableStateFlow(VoiceLanguage.HINDI)
    val currentLanguage: StateFlow<VoiceLanguage> = _currentLanguage.asStateFlow()

    fun setLanguage(language: VoiceLanguage) {
        _currentLanguage.value = language
    }

    /**
     * Checks if Speech Recognition is supported on this Android device.
     */
    fun isRecognitionAvailable(): Boolean {
        return SpeechRecognizer.isRecognitionAvailable(context)
    }

    /**
     * Starts listening for user speech using the selected language.
     * Must be executed on the Main thread.
     */
    fun startListening(
        onPartialResult: ((String) -> Unit)? = null,
        onFinalResult: ((String) -> Unit)? = null,
        onErrorResult: ((String) -> Unit)? = null
    ) {
        mainHandler.post {
            if (!isRecognitionAvailable()) {
                val errorMsg = "Speech recognition is not available on this device."
                _state.value = SpeechRecognitionState.Error(errorMsg)
                onErrorResult?.invoke(errorMsg)
                return@post
            }

            // Stop any existing session
            stopListeningInternal()

            try {
                _state.value = SpeechRecognitionState.Initializing
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                    setRecognitionListener(object : RecognitionListener {
                        override fun onReadyForSpeech(params: Bundle?) {
                            Log.d(tag, "onReadyForSpeech")
                            isCurrentlyListening = true
                            _state.value = SpeechRecognitionState.Ready
                        }

                        override fun onBeginningOfSpeech() {
                            Log.d(tag, "onBeginningOfSpeech")
                            _state.value = SpeechRecognitionState.Listening(0f)
                        }

                        override fun onRmsChanged(rmsdB: Float) {
                            // rmsdB typically ranges from -2 to 10
                            val normalized = (rmsdB.coerceIn(-2f, 10f) + 2f) / 12f
                            _rmsLevel.value = normalized
                            if (isCurrentlyListening) {
                                _state.value = SpeechRecognitionState.Listening(normalized)
                            }
                        }

                        override fun onBufferReceived(buffer: ByteArray?) {}

                        override fun onEndOfSpeech() {
                            Log.d(tag, "onEndOfSpeech")
                            isCurrentlyListening = false
                        }

                        override fun onError(error: Int) {
                            isCurrentlyListening = false
                            val errorMessage = mapErrorCodeToMessage(error)
                            Log.w(tag, "onError: code=$error msg=$errorMessage")
                            _rmsLevel.value = 0f
                            _state.value = SpeechRecognitionState.Error(errorMessage, error)
                            onErrorResult?.invoke(errorMessage)
                        }

                        override fun onResults(results: Bundle?) {
                            isCurrentlyListening = false
                            _rmsLevel.value = 0f
                            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            val recognizedText = matches?.firstOrNull()?.trim().orEmpty()
                            Log.d(tag, "onResults: $recognizedText")

                            if (recognizedText.isNotBlank()) {
                                _state.value = SpeechRecognitionState.Recognized(recognizedText, isFinal = true)
                                onFinalResult?.invoke(recognizedText)
                            } else {
                                _state.value = SpeechRecognitionState.Idle
                            }
                        }

                        override fun onPartialResults(partialResults: Bundle?) {
                            val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            val partialText = matches?.firstOrNull()?.trim().orEmpty()
                            if (partialText.isNotBlank()) {
                                _state.value = SpeechRecognitionState.Recognized(partialText, isFinal = false)
                                onPartialResult?.invoke(partialText)
                            }
                        }

                        override fun onEvent(eventType: Int, params: Bundle?) {}
                    })
                }

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(
                        RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                    )
                    val lang = _currentLanguage.value
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang.tag)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, lang.tag)
                    putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
                    putExtra("android.speech.extra.DICTATION_MODE", true)
                }

                speechRecognizer?.startListening(intent)
            } catch (e: Exception) {
                Log.e(tag, "Exception during startListening", e)
                isCurrentlyListening = false
                val msg = e.localizedMessage ?: "Could not start speech recognition."
                _state.value = SpeechRecognitionState.Error(msg)
                onErrorResult?.invoke(msg)
            }
        }
    }

    /**
     * Stops listening and requests final results from the current audio stream.
     */
    fun stopListening() {
        mainHandler.post {
            stopListeningInternal()
        }
    }

    private fun stopListeningInternal() {
        try {
            isCurrentlyListening = false
            _rmsLevel.value = 0f
            speechRecognizer?.stopListening()
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
            speechRecognizer = null
            if (_state.value is SpeechRecognitionState.Listening || _state.value is SpeechRecognitionState.Initializing) {
                _state.value = SpeechRecognitionState.Idle
            }
        } catch (e: Exception) {
            Log.w(tag, "Error stopping recognizer", e)
        }
    }

    /**
     * Resets recognizer to idle state.
     */
    fun reset() {
        mainHandler.post {
            stopListeningInternal()
            _state.value = SpeechRecognitionState.Idle
        }
    }

    /**
     * Destroys the recognizer and releases audio hardware resources.
     */
    fun destroy() {
        mainHandler.post {
            stopListeningInternal()
        }
    }

    private fun mapErrorCodeToMessage(errorCode: Int): String {
        return when (errorCode) {
            SpeechRecognizer.ERROR_AUDIO -> "Audio recording error. Please check your mic."
            SpeechRecognizer.ERROR_CLIENT -> "Speech recognition client error."
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is required."
            SpeechRecognizer.ERROR_NETWORK -> "Network error during speech recognition."
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout. Please try again."
            SpeechRecognizer.ERROR_NO_MATCH -> "Muskan couldn't catch that. Please speak clearly."
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Voice recognizer is busy. Retrying..."
            SpeechRecognizer.ERROR_SERVER -> "Server error. Please try again later."
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected. Tap mic to speak."
            else -> "Speech recognition error ($errorCode)"
        }
    }
}
