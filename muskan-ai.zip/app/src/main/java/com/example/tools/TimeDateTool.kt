package com.example.tools

import org.json.JSONObject
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

class TimeDateTool : Tool {
    override val name = "get_time_date"
    override val description = "Get current date, time, day of week, and timezone information."
    override val parameterSchema = JSONObject().apply {
        put("type", "OBJECT")
        put("properties", JSONObject())
    }

    override suspend fun execute(args: JSONObject): ToolExecutionResult {
        return try {
            val now = ZonedDateTime.now(ZoneId.systemDefault())
            val formatter = DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy - hh:mm:ss a z", Locale.getDefault())
            val formatted = now.format(formatter)
            ToolExecutionResult(
                toolName = name,
                success = true,
                output = "Current Date and Time: $formatted"
            )
        } catch (e: Exception) {
            ToolExecutionResult(
                toolName = name,
                success = false,
                output = "Failed to retrieve time/date: ${e.localizedMessage}"
            )
        }
    }
}
