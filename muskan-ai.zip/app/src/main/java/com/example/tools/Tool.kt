package com.example.tools

import org.json.JSONObject

/**
 * Interface defining an executable tool available to Muskan AI.
 */
interface Tool {
    val name: String
    val description: String
    val parameterSchema: JSONObject

    suspend fun execute(args: JSONObject): ToolExecutionResult
}
