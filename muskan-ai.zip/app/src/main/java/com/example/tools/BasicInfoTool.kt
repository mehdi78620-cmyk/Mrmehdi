package com.example.tools

import org.json.JSONObject

class BasicInfoTool : Tool {
    override val name = "basic_info_retrieval"
    override val description = "Retrieve encyclopedic definitions, historical facts, and general knowledge."
    override val parameterSchema = JSONObject().apply {
        put("type", "OBJECT")
        put("properties", JSONObject().apply {
            put("topic", JSONObject().apply {
                put("type", "STRING")
                put("description", "Topic, term, or question to look up")
            })
        })
        put("required", org.json.JSONArray().put("topic"))
    }

    override suspend fun execute(args: JSONObject): ToolExecutionResult {
        val topic = args.optString("topic", "").trim()
        if (topic.isEmpty()) {
            return ToolExecutionResult(name, false, "Topic cannot be empty.")
        }
        return ToolExecutionResult(
            toolName = name,
            success = true,
            output = "Information retrieval for '$topic': Request processed successfully."
        )
    }
}
