package com.example.tools

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder

class WeatherTool(
    private val httpClient: OkHttpClient = OkHttpClient()
) : Tool {
    override val name = "get_weather"
    override val description = "Get real-time weather information (temperature, humidity, wind speed) for any city or location."
    override val parameterSchema = JSONObject().apply {
        put("type", "OBJECT")
        put("properties", JSONObject().apply {
            put("location", JSONObject().apply {
                put("type", "STRING")
                put("description", "City name, e.g. New York, Tokyo, Delhi, London")
            })
        })
        put("required", org.json.JSONArray().put("location"))
    }

    override suspend fun execute(args: JSONObject): ToolExecutionResult = withContext(Dispatchers.IO) {
        val location = args.optString("location", "").trim()
        if (location.isEmpty()) {
            return@withContext ToolExecutionResult(name, false, "Location is required for weather lookup.")
        }

        try {
            val encodedLoc = URLEncoder.encode(location, "UTF-8")
            val geoUrl = "https://geocoding-api.open-meteo.com/v1/search?name=$encodedLoc&count=1&language=en&format=json"
            val geoReq = Request.Builder().url(geoUrl).get().build()

            httpClient.newCall(geoReq).execute().use { geoResp ->
                val geoBody = geoResp.body?.string() ?: ""
                if (!geoResp.isSuccessful || geoBody.isEmpty()) {
                    return@withContext ToolExecutionResult(name, false, "Could not find coordinates for location '$location'.")
                }

                val geoJson = JSONObject(geoBody)
                val results = geoJson.optJSONArray("results")
                if (results == null || results.length() == 0) {
                    return@withContext ToolExecutionResult(name, false, "Location '$location' not found.")
                }

                val place = results.getJSONObject(0)
                val lat = place.getDouble("latitude")
                val lon = place.getDouble("longitude")
                val cityName = place.optString("name", location)
                val country = place.optString("country", "")

                val weatherUrl = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m"
                val weatherReq = Request.Builder().url(weatherUrl).get().build()

                httpClient.newCall(weatherReq).execute().use { weatherResp ->
                    val weatherBody = weatherResp.body?.string() ?: ""
                    if (!weatherResp.isSuccessful || weatherBody.isEmpty()) {
                        return@withContext ToolExecutionResult(name, false, "Failed to retrieve weather data for $cityName.")
                    }

                    val weatherJson = JSONObject(weatherBody)
                    val current = weatherJson.optJSONObject("current")
                        ?: return@withContext ToolExecutionResult(name, false, "Weather data unavailable for $cityName.")

                    val temp = current.optDouble("temperature_2m", 0.0)
                    val humidity = current.optInt("relative_humidity_2m", 0)
                    val windSpeed = current.optDouble("wind_speed_10m", 0.0)
                    val weatherCode = current.optInt("weather_code", 0)
                    val conditionDesc = getWeatherConditionDescription(weatherCode)

                    val summary = "Weather in $cityName${if (country.isNotBlank()) ", $country" else ""}:\n" +
                            "• Temperature: $temp°C ($conditionDesc)\n" +
                            "• Humidity: $humidity%\n" +
                            "• Wind Speed: $windSpeed km/h"

                    ToolExecutionResult(
                        toolName = name,
                        success = true,
                        output = summary,
                        sources = listOf(ToolSource("Open-Meteo Weather API", "https://open-meteo.com/"))
                    )
                }
            }
        } catch (e: Exception) {
            ToolExecutionResult(
                toolName = name,
                success = false,
                output = "Weather lookup error: ${e.localizedMessage ?: "Network failed"}"
            )
        }
    }

    private fun getWeatherConditionDescription(code: Int): String {
        return when (code) {
            0 -> "Clear sky"
            1, 2, 3 -> "Partly cloudy"
            45, 48 -> "Foggy"
            51, 53, 55 -> "Drizzle"
            61, 63, 65 -> "Rain"
            71, 73, 75 -> "Snow"
            95, 96, 99 -> "Thunderstorm"
            else -> "Fair"
        }
    }
}
