package com.example.tools

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder

class WebSearchTool(
    private val httpClient: OkHttpClient = OkHttpClient()
) : Tool {
    override val name = "web_search"
    override val description = "Search the web for real-time news, facts, articles, and current information."
    override val parameterSchema = JSONObject().apply {
        put("type", "OBJECT")
        put("properties", JSONObject().apply {
            put("query", JSONObject().apply {
                put("type", "STRING")
                put("description", "Search query term")
            })
        })
        put("required", org.json.JSONArray().put("query"))
    }

    override suspend fun execute(args: JSONObject): ToolExecutionResult = withContext(Dispatchers.IO) {
        val query = args.optString("query", "").trim()
        if (query.isEmpty()) {
            return@withContext ToolExecutionResult(name, false, "Search query cannot be empty.")
        }

        try {
            val encodedQuery = URLEncoder.encode(query, "UTF-8")
            val url = "https://api.duckduckgo.com/?q=$encodedQuery&format=json&no_html=1&skip_disambig=1"
            val request = Request.Builder().url(url).get().build()

            httpClient.newCall(request).execute().use { response ->
                val body = response.body?.string() ?: ""
                if (!response.isSuccessful || body.isEmpty()) {
                    return@withContext ToolExecutionResult(name, false, "Web search request failed.")
                }

                val json = JSONObject(body)
                val abstractText = json.optString("AbstractText", "")
                val abstractSource = json.optString("AbstractSource", "")
                val abstractUrl = json.optString("AbstractURL", "")

                val resultsBuilder = StringBuilder()
                val sources = mutableListOf<ToolSource>()

                if (abstractText.isNotBlank()) {
                    resultsBuilder.append("Summary: $abstractText\n")
                    if (abstractUrl.isNotBlank()) {
                        sources.add(ToolSource(if (abstractSource.isNotBlank()) abstractSource else "DuckDuckGo", abstractUrl))
                    }
                }

                val relatedTopics = json.optJSONArray("RelatedTopics")
                if (relatedTopics != null) {
                    var count = 0
                    for (i in 0 until relatedTopics.length()) {
                        val topic = relatedTopics.optJSONObject(i) ?: continue
                        val text = topic.optString("Text", "")
                        val firstUrl = topic.optString("FirstURL", "")
                        if (text.isNotBlank()) {
                            resultsBuilder.append("• $text\n")
                            if (firstUrl.isNotBlank() && sources.size < 3) {
                                sources.add(ToolSource("Source #${sources.size + 1}", firstUrl))
                            }
                            count++
                            if (count >= 4) break
                        }
                    }
                }

                val finalOutput = resultsBuilder.toString().trim()
                if (finalOutput.isEmpty()) {
                    ToolExecutionResult(
                        toolName = name,
                        success = true,
                        output = "No direct instant web results found for '$query'. Try asking with more specific keywords."
                    )
                } else {
                    ToolExecutionResult(
                        toolName = name,
                        success = true,
                        output = finalOutput,
                        sources = sources
                    )
                }
            }
        } catch (e: Exception) {
            ToolExecutionResult(
                toolName = name,
                success = false,
                output = "Web search error: ${e.localizedMessage ?: "Connection error"}"
            )
        }
    }
}
