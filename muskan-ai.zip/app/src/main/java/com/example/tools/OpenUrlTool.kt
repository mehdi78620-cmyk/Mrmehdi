package com.example.tools

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

class OpenUrlTool(
    private val httpClient: OkHttpClient = OkHttpClient()
) : Tool {
    override val name = "open_url"
    override val description = "Open, validate, or fetch headers and metadata for a given web URL."
    override val parameterSchema = JSONObject().apply {
        put("type", "OBJECT")
        put("properties", JSONObject().apply {
            put("url", JSONObject().apply {
                put("type", "STRING")
                put("description", "Valid HTTP or HTTPS web URL to inspect")
            })
        })
        put("required", org.json.JSONArray().put("url"))
    }

    override suspend fun execute(args: JSONObject): ToolExecutionResult = withContext(Dispatchers.IO) {
        var urlStr = args.optString("url", "").trim()
        if (urlStr.isEmpty()) {
            return@withContext ToolExecutionResult(name, false, "URL cannot be empty.")
        }
        if (!urlStr.startsWith("http://") && !urlStr.startsWith("https://")) {
            urlStr = "https://$urlStr"
        }

        return@withContext try {
            val request = Request.Builder().url(urlStr).head().build()
            httpClient.newCall(request).execute().use { response ->
                val code = response.code
                val contentType = response.header("Content-Type", "Unknown")
                val success = response.isSuccessful || code in 200..399

                val info = "URL: $urlStr\nStatus Code: $code\nContent-Type: $contentType\nReachable: ${if (success) "Yes" else "No (HTTP $code)"}"
                ToolExecutionResult(
                    toolName = name,
                    success = true,
                    output = info,
                    sources = listOf(ToolSource("Target URL", urlStr))
                )
            }
        } catch (e: Exception) {
            ToolExecutionResult(
                toolName = name,
                success = false,
                output = "Could not open or reach URL '$urlStr': ${e.localizedMessage ?: "Connection failed"}"
            )
        }
    }
}
