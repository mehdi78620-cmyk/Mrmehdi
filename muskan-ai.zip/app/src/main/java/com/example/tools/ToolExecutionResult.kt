package com.example.tools

data class ToolSource(
    val title: String,
    val url: String
)

data class ToolExecutionResult(
    val toolName: String,
    val success: Boolean,
    val output: String,
    val sources: List<ToolSource> = emptyList()
)
