package com.example.tools

import org.json.JSONArray
import org.json.JSONObject

class ToolCallingEngine {
    private val toolsMap = mutableMapOf<String, Tool>()

    init {
        registerTool(WeatherTool())
        registerTool(CalculatorTool())
        registerTool(TimeDateTool())
        registerTool(WebSearchTool())
        registerTool(OpenUrlTool())
        registerTool(BasicInfoTool())
    }

    private fun registerTool(tool: Tool) {
        toolsMap[tool.name] = tool
    }

    fun getTool(name: String): Tool? = toolsMap[name]

    fun getAllTools(): List<Tool> = toolsMap.values.toList()

    fun getGeminiToolDeclarations(): JSONArray {
        val functionDeclarations = JSONArray()
        for (tool in toolsMap.values) {
            val decl = JSONObject().apply {
                put("name", tool.name)
                put("description", tool.description)
                put("parameters", tool.parameterSchema)
            }
            functionDeclarations.put(decl)
        }

        val toolsWrapper = JSONArray()
        toolsWrapper.put(JSONObject().put("functionDeclarations", functionDeclarations))
        return toolsWrapper
    }

    suspend fun executeTool(name: String, args: JSONObject): ToolExecutionResult {
        val tool = toolsMap[name] ?: return ToolExecutionResult(
            toolName = name,
            success = false,
            output = "Unknown tool '$name'."
        )
        return tool.execute(args)
    }
}
