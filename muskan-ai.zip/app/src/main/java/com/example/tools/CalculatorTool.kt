package com.example.tools

import org.json.JSONObject
import kotlin.math.*

class CalculatorTool : Tool {
    override val name = "calculator"
    override val description = "Evaluate a mathematical expression (supports arithmetic +, -, *, /, %, power ^, sqrt, sin, cos)."
    override val parameterSchema = JSONObject().apply {
        put("type", "OBJECT")
        put("properties", JSONObject().apply {
            put("expression", JSONObject().apply {
                put("type", "STRING")
                put("description", "Mathematical expression to evaluate, e.g. 45 * 12 / 3 or sqrt(144)")
            })
        })
        put("required", org.json.JSONArray().put("expression"))
    }

    override suspend fun execute(args: JSONObject): ToolExecutionResult {
        val expr = args.optString("expression", "").trim()
        if (expr.isEmpty()) {
            return ToolExecutionResult(name, false, "Expression cannot be empty.")
        }
        return try {
            val result = evaluateExpression(expr)
            ToolExecutionResult(
                toolName = name,
                success = true,
                output = "Result of '$expr' = $result"
            )
        } catch (e: Exception) {
            ToolExecutionResult(
                toolName = name,
                success = false,
                output = "Could not evaluate '$expr': ${e.localizedMessage}"
            )
        }
    }

    private fun evaluateExpression(str: String): Double {
        return object : Any() {
            var pos = -1
            var ch = 0

            fun nextChar() {
                ch = if (++pos < str.length) str[pos].toInt() else -1
            }

            fun eat(charToEat: Int): Boolean {
                while (ch == ' '.toInt()) nextChar()
                if (ch == charToEat) {
                    nextChar()
                    return true
                }
                return false
            }

            fun parse(): Double {
                nextChar()
                val x = parseExpression()
                if (pos < str.length) throw RuntimeException("Unexpected character: " + ch.toChar())
                return x
            }

            fun parseExpression(): Double {
                var x = parseTerm()
                while (true) {
                    if (eat('+'.toInt())) x += parseTerm()
                    else if (eat('-'.toInt())) x -= parseTerm()
                    else return x
                }
            }

            fun parseTerm(): Double {
                var x = parseFactor()
                while (true) {
                    if (eat('*'.toInt())) x *= parseFactor()
                    else if (eat('/'.toInt())) x /= parseFactor()
                    else if (eat('%'.toInt())) x %= parseFactor()
                    else return x
                }
            }

            fun parseFactor(): Double {
                if (eat('+'.toInt())) return parseFactor()
                if (eat('-'.toInt())) return -parseFactor()
                var x: Double
                val startPos = pos
                if (eat('('.toInt())) {
                    x = parseExpression()
                    eat(')'.toInt())
                } else if (ch >= '0'.toInt() && ch <= '9'.toInt() || ch == '.'.toInt()) {
                    while (ch >= '0'.toInt() && ch <= '9'.toInt() || ch == '.'.toInt()) nextChar()
                    x = str.substring(startPos, pos).toDouble()
                } else if (ch >= 'a'.toInt() && ch <= 'z'.toInt()) {
                    while (ch >= 'a'.toInt() && ch <= 'z'.toInt()) nextChar()
                    val func = str.substring(startPos, pos)
                    eat('('.toInt())
                    x = parseExpression()
                    eat(')'.toInt())
                    x = when (func) {
                        "sqrt" -> sqrt(x)
                        "sin" -> sin(Math.toRadians(x))
                        "cos" -> cos(Math.toRadians(x))
                        "tan" -> tan(Math.toRadians(x))
                        "abs" -> abs(x)
                        else -> throw RuntimeException("Unknown function: $func")
                    }
                } else {
                    throw RuntimeException("Unexpected character: " + ch.toChar())
                }

                if (eat('^'.toInt())) x = x.pow(parseFactor())
                return x
            }
        }.parse()
    }
}
